/**
 * main.js
 * Frontend controller for Steel Industry Waste Segregation System
 */

document.addEventListener("DOMContentLoaded", () => {
  const dropZone = document.getElementById("dropZone");
  const imageInput = document.getElementById("imageInput");
  const browseBtn = document.getElementById("browseBtn");
  const previewContainer = document.getElementById("previewContainer");
  const imagePreview = document.getElementById("imagePreview");
  const fileNameDisplay = document.getElementById("fileNameDisplay");
  const removeImgBtn = document.getElementById("removeImgBtn");
  const classifyBtn = document.getElementById("classifyBtn");
  const loadingState = document.getElementById("loadingState");
  const errorAlert = document.getElementById("errorAlert");
  const errorMessage = document.getElementById("errorMessage");
  const resultCard = document.getElementById("resultCard");
  const categoryDisplay = document.getElementById("categoryDisplay");
  const confidenceDisplay = document.getElementById("confidenceDisplay");
  const confidenceBar = document.getElementById("confidenceBar");
  const recommendationDisplay = document.getElementById("recommendationDisplay");
  const statusBadge = document.getElementById("statusBadge");

  let currentFile = null;

  // Trigger file selection dialog
  browseBtn.addEventListener("click", () => imageInput.click());
  dropZone.addEventListener("click", (e) => {
    if (e.target !== browseBtn) {
      imageInput.click();
    }
  });

  // Handle Drag & Drop events
  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("dragover");
    });
  });

  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("dragover");
    });
  });

  dropZone.addEventListener("drop", (e) => {
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelected(files[0]);
    }
  });

  // Handle file input change
  imageInput.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
      handleFileSelected(e.target.files[0]);
    }
  });

  // Validate and display image preview
  function handleFileSelected(file) {
    const validExtensions = ["image/jpeg", "image/jpg", "image/png"];
    if (!validExtensions.includes(file.type)) {
      showError("Invalid file type. Please upload a JPG, JPEG, or PNG image.");
      return;
    }

    currentFile = file;
    fileNameDisplay.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;

    const reader = new FileReader();
    reader.onload = (e) => {
      imagePreview.src = e.target.result;
      previewContainer.classList.remove("d-none");
      dropZone.classList.add("d-none");
      classifyBtn.disabled = false;
      hideError();
      resultCard.classList.add("d-none");
    };
    reader.readAsDataURL(file);
  }

  // Remove selected image
  removeImgBtn.addEventListener("click", () => {
    currentFile = null;
    imageInput.value = "";
    previewContainer.classList.add("d-none");
    dropZone.classList.remove("d-none");
    classifyBtn.disabled = true;
    resultCard.classList.add("d-none");
    hideError();
  });

  // Classify Waste Button Click
  classifyBtn.addEventListener("click", async () => {
    if (!currentFile) {
      showError("Please select a waste image first.");
      return;
    }

    // Set UI loading state
    classifyBtn.disabled = true;
    loadingState.classList.remove("d-none");
    resultCard.classList.add("d-none");
    hideError();

    const formData = new FormData();
    formData.append("image", currentFile);

    try {
      const response = await fetch("/predict", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to classify image.");
      }

      displayResults(data);

    } catch (err) {
      showError("Unable to identify the waste. Please upload a clearer image.");
      console.error(err);
    } finally {
      loadingState.classList.add("d-none");
      classifyBtn.disabled = false;
    }
  });

  function displayResults(data) {
    resultCard.classList.remove("d-none");

    const category = data.class || "Unknown";
    const confidence = parseFloat(data.confidence) || 0.0;
    const recommendation = data.recommendation || "Separate according to plant safety guidelines.";

    categoryDisplay.textContent = category.toUpperCase();
    confidenceDisplay.textContent = `${confidence.toFixed(1)}%`;
    confidenceBar.style.width = `${Math.min(confidence, 100)}%`;
    recommendationDisplay.textContent = recommendation;

    // Check low confidence condition (< 60%)
    if (confidence < 60 || category.toLowerCase().includes("unknown") || data.status === "low_confidence") {
      statusBadge.className = "badge bg-warning text-dark px-3 py-2 rounded-pill";
      statusBadge.textContent = "Low Confidence";
      confidenceBar.className = "progress-bar bg-warning";
      showError("Unable to confidently identify this waste. Please upload a clearer image.");
    } else {
      statusBadge.className = "badge bg-success px-3 py-2 rounded-pill";
      statusBadge.textContent = "Classified";
      confidenceBar.className = "progress-bar bg-success";
      hideError();
    }

    // Smooth scroll to results
    resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function showError(msg) {
    errorMessage.textContent = msg;
    errorAlert.classList.remove("d-none");
  }

  function hideError() {
    errorAlert.classList.add("d-none");
  }
});

/**
 * camera.js
 * Frontend controller for Live Waste Detection using HTML5 Webcam API
 * Second-Year B.Tech Mini Project
 */

document.addEventListener("DOMContentLoaded", () => {
  const video = document.getElementById("webcamVideo");
  const canvas = document.getElementById("captureCanvas");
  const startBtn = document.getElementById("startCameraBtn");
  const stopBtn = document.getElementById("stopCameraBtn");
  const placeholder = document.getElementById("cameraPlaceholder");
  const guideBox = document.getElementById("guideBox");
  const hudOverlay = document.getElementById("cameraOverlayHud");
  const hudWaste = document.getElementById("hudWaste");
  const hudConfidence = document.getElementById("hudConfidence");
  const cameraStatusIndicator = document.getElementById("cameraStatusIndicator");
  const fpsBadge = document.getElementById("fpsBadge");
  const errorAlert = document.getElementById("cameraErrorAlert");
  const errorMessage = document.getElementById("cameraErrorMessage");

  const categoryDisplay = document.getElementById("liveCategoryDisplay");
  const confidenceDisplay = document.getElementById("liveConfidenceDisplay");
  const confidenceBar = document.getElementById("liveConfidenceBar");
  const recommendationDisplay = document.getElementById("liveRecommendationDisplay");
  const statusBadge = document.getElementById("liveStatusBadge");

  let mediaStream = null;
  let captureIntervalId = null;
  let isProcessingFrame = false;

  // Capture rate: 1.25 frames per second (every 800ms) to avoid overloading backend
  const CAPTURE_INTERVAL_MS = 800;

  // Start Camera
  startBtn.addEventListener("click", async () => {
    hideError();
    startBtn.disabled = true;

    try {
      // Request camera stream
      mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "environment" // Prefer back camera if mobile, else webcam
        },
        audio: false
      });

      video.srcObject = mediaStream;

      video.onloadedmetadata = () => {
        video.play();
        placeholder.classList.add("d-none");
        guideBox.classList.remove("d-none");
        hudOverlay.classList.remove("d-none");
        fpsBadge.classList.remove("d-none");

        cameraStatusIndicator.className = "badge bg-success";
        cameraStatusIndicator.textContent = "Camera Active";

        startBtn.disabled = true;
        stopBtn.disabled = false;

        // Start periodic frame capture
        startPeriodicCapture();
      };

    } catch (err) {
      console.error("Camera access error:", err);
      showError("Could not access camera. Please allow camera permissions in your browser: " + err.message);
      startBtn.disabled = false;
      stopBtn.disabled = true;
    }
  });

  // Stop Camera
  stopBtn.addEventListener("click", stopCamera);

  function stopCamera() {
    if (captureIntervalId) {
      clearInterval(captureIntervalId);
      captureIntervalId = null;
    }

    if (mediaStream) {
      mediaStream.getTracks().forEach((track) => track.stop());
      mediaStream = null;
    }

    video.srcObject = null;
    placeholder.classList.remove("d-none");
    guideBox.classList.add("d-none");
    hudOverlay.classList.add("d-none");
    fpsBadge.classList.add("d-none");

    cameraStatusIndicator.className = "badge bg-secondary";
    cameraStatusIndicator.textContent = "Camera Offline";

    startBtn.disabled = false;
    stopBtn.disabled = true;

    // Reset displays
    categoryDisplay.textContent = "-";
    confidenceDisplay.textContent = "0%";
    confidenceBar.style.width = "0%";
    recommendationDisplay.textContent = "Camera stopped. Start camera to resume detection.";
    statusBadge.className = "badge bg-secondary px-3 py-2 rounded-pill";
    statusBadge.textContent = "Offline";
  }

  // Periodic Frame Capture
  function startPeriodicCapture() {
    if (captureIntervalId) clearInterval(captureIntervalId);

    captureIntervalId = setInterval(async () => {
      // Avoid queueing concurrent network requests if one is still in flight
      if (isProcessingFrame || !mediaStream || video.videoWidth === 0) {
        return;
      }

      isProcessingFrame = true;
      try {
        await captureAndPredictFrame();
      } catch (err) {
        console.warn("Frame analysis error:", err);
      } finally {
        isProcessingFrame = false;
      }
    }, CAPTURE_INTERVAL_MS);
  }

  // Grabs frame from <video>, downsamples to 224x224, sends to Flask POST /predict_frame
  async function captureAndPredictFrame() {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Draw current video frame scaled into 224x224 canvas
    ctx.drawImage(video, 0, 0, 224, 224);

    // Convert canvas image to base64 JPEG format
    const base64Data = canvas.toDataURL("image/jpeg", 0.85);

    const response = await fetch("/predict_frame", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ frame: base64Data })
    });

    if (!response.ok) {
      throw new Error(`Server returned status ${response.status}`);
    }

    const data = await response.json();
    updateDetectionUI(data);
  }

  // Update HUD and Result Panel with model response
  function updateDetectionUI(data) {
    const rawClass = data.class || "Object not confidently identified.";
    const confidence = parseFloat(data.confidence) || 0.0;
    const recommendation = data.recommendation || "Unable to identify. Ensure one waste item is placed inside the guide box.";

    // Threshold check (60%)
    const isConfident = confidence >= 60.0 && !rawClass.includes("not confidently");

    if (isConfident) {
      // Confident detection
      hudWaste.textContent = `Waste: ${rawClass}`;
      hudConfidence.textContent = `Confidence: ${confidence.toFixed(1)}%`;
      hudConfidence.className = "small text-success fw-bold";

      categoryDisplay.textContent = rawClass.toUpperCase();
      confidenceDisplay.textContent = `${confidence.toFixed(1)}%`;
      confidenceBar.style.width = `${Math.min(confidence, 100)}%`;
      confidenceBar.className = "progress-bar bg-success";

      recommendationDisplay.textContent = recommendation;
      statusBadge.className = "badge bg-success px-3 py-2 rounded-pill";
      statusBadge.textContent = "Detected";
    } else {
      // Below 60% confidence: Display "Object not confidently identified."
      hudWaste.textContent = "Waste: Unidentified";
      hudConfidence.textContent = `Confidence: ${confidence.toFixed(1)}% (<60%)`;
      hudConfidence.className = "small text-warning";

      categoryDisplay.textContent = "Object not confidently identified.";
      confidenceDisplay.textContent = `${confidence.toFixed(1)}%`;
      confidenceBar.style.width = `${Math.min(confidence, 100)}%`;
      confidenceBar.className = "progress-bar bg-warning";

      recommendationDisplay.textContent = "Place one waste item clearly inside the center guide box for confident classification.";
      statusBadge.className = "badge bg-warning text-dark px-3 py-2 rounded-pill";
      statusBadge.textContent = "Low Confidence";
    }
  }

  function showError(msg) {
    errorMessage.textContent = msg;
    errorAlert.classList.remove("d-none");
  }

  function hideError() {
    errorAlert.classList.add("d-none");
  }

  // Cleanup camera if user leaves the tab
  window.addEventListener("beforeunload", () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach((track) => track.stop());
    }
  });
});

"""
predict.py
----------
Prediction module for the Image-Based Steel Industry Waste Segregation System.
Supports both single image files and real-time live camera frames.

Academic Level: Second-Year B.Tech Mini Project
Target Classes:
  0: Steel Scrap
  1: Metal Turnings
  2: Other Waste
"""

import os
import base64
import io
import numpy as np
from PIL import Image

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import tensorflow as tf
    from tensorflow.keras.models import load_model
    from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
except ImportError:
    tf = None
    load_model = None
    preprocess_input = None

# Configuration constants
IMAGE_SIZE = (224, 224)
CONFIDENCE_THRESHOLD = 60.0  # Predefined 60% threshold
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'steel_waste_model.keras')

CLASSES = [
    "Steel Scrap",
    "Metal Turnings",
    "Other Waste"
]

RECOMMENDATIONS = {
    "Steel Scrap": "Send the material for appropriate steel recycling/reprocessing.",
    "Metal Turnings": "Collect separately and send for metal recycling/recovery.",
    "Other Waste": "Separate manually and dispose of according to the material type.",
    "Low Confidence": "Unable to identify. Ensure one waste item is clearly placed inside the guide box."
}

_cached_model = None


def get_model():
    """
    Loads and caches the trained Keras model from disk.
    """
    global _cached_model
    if _cached_model is not None:
        return _cached_model

    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"Trained model not found at '{MODEL_PATH}'. "
            "Please run 'python train_model.py' first to train and save the model."
        )

    print(f"[*] Loading model from {MODEL_PATH}...")
    _cached_model = load_model(MODEL_PATH)
    print("[+] Model loaded successfully.")
    return _cached_model


def preprocess_numpy_frame(frame):
    """
    Preprocesses a raw OpenCV/NumPy BGR or RGB frame from the webcam:
    1. If BGR (OpenCV default), convert to RGB.
    2. Resize frame to (224, 224).
    3. Convert to float32 NumPy array.
    4. Normalize pixel values using MobileNetV2 scaling (maps [0, 255] to [-1, 1]).
    5. Add batch dimension -> (1, 224, 224, 3).
    """
    # 1. Convert to RGB if needed
    if len(frame.shape) == 3 and frame.shape[2] == 3:
        if cv2 is not None:
            # Assume BGR if from standard cv2 decode
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        else:
            rgb_frame = frame
    else:
        rgb_frame = frame

    # 2. Resize to 224x224
    if cv2 is not None:
        resized = cv2.resize(rgb_frame, IMAGE_SIZE, interpolation=cv2.INTER_LINEAR)
    else:
        pil_img = Image.fromarray(rgb_frame.astype('uint8')).resize(IMAGE_SIZE, Image.Resampling.BILINEAR)
        resized = np.array(pil_img)

    # 3. Float32 & Batch dimension
    img_array = np.array(resized, dtype=np.float32)
    img_batch = np.expand_dims(img_array, axis=0)

    # 4. Normalize using MobileNetV2 standard preprocessing (scale [-1, 1])
    if preprocess_input is not None:
        preprocessed = preprocess_input(img_batch)
    else:
        preprocessed = (img_batch / 127.5) - 1.0

    return preprocessed


def predict_frame(frame_array):
    """
    Accepts an OpenCV/NumPy video frame, runs inference, and returns prediction.
    Threshold: < 60% returns 'Object not confidently identified.'
    """
    try:
        input_tensor = preprocess_numpy_frame(frame_array)
        model = get_model()
        raw_predictions = model.predict(input_tensor, verbose=0)[0]

        best_index = int(np.argmax(raw_predictions))
        confidence_percentage = round(float(raw_predictions[best_index]) * 100.0, 2)
        predicted_class = CLASSES[best_index]

        all_scores = {
            CLASSES[i]: round(float(raw_predictions[i]) * 100.0, 2)
            for i in range(len(CLASSES))
        }

        # Confidence handling: below 60%
        if confidence_percentage < CONFIDENCE_THRESHOLD:
            return {
                "class": "Object not confidently identified.",
                "confidence": confidence_percentage,
                "recommendation": RECOMMENDATIONS["Low Confidence"],
                "all_scores": all_scores,
                "status": "low_confidence",
                "raw_class": predicted_class
            }

        # Confident detection
        return {
            "class": predicted_class,
            "confidence": confidence_percentage,
            "recommendation": RECOMMENDATIONS.get(predicted_class, "Process according to plant standards."),
            "all_scores": all_scores,
            "status": "success",
            "raw_class": predicted_class
        }

    except Exception as e:
        return {
            "class": "Error",
            "confidence": 0.0,
            "recommendation": "Error occurred during frame prediction.",
            "error": str(e),
            "status": "error"
        }


def predict_base64_frame(base64_str):
    """
    Decodes a base64 image string (data:image/jpeg;base64,...), converts to OpenCV frame,
    and runs predict_frame().
    """
    try:
        if "," in base64_str:
            base64_str = base64_str.split(",", 1)[1]

        image_bytes = base64.b64decode(base64_str)
        nparr = np.frombuffer(image_bytes, np.uint8)

        if cv2 is not None:
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        else:
            pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            frame = np.array(pil_img)

        if frame is None:
            return {
                "class": "Object not confidently identified.",
                "confidence": 0.0,
                "recommendation": "Invalid image data received from camera stream.",
                "status": "error"
            }

        return predict_frame(frame)

    except Exception as e:
        return {
            "class": "Error",
            "confidence": 0.0,
            "recommendation": "Failed to decode camera frame.",
            "error": str(e),
            "status": "error"
        }


def preprocess_image(image_path):
    """
    Loads and preprocesses an image file from disk.
    """
    img = Image.open(image_path)
    if img.mode != "RGB":
        img = img.convert("RGB")
    img = img.resize(IMAGE_SIZE, Image.Resampling.BILINEAR)
    img_array = np.array(img, dtype=np.float32)
    img_batch = np.expand_dims(img_array, axis=0)

    if preprocess_input is not None:
        return preprocess_input(img_batch)
    return (img_batch / 127.5) - 1.0


def predict_image(image_path):
    """
    Accepts the path of an uploaded waste image file and returns prediction results.
    """
    try:
        input_tensor = preprocess_image(image_path)
        model = get_model()
        raw_predictions = model.predict(input_tensor, verbose=0)[0]

        best_index = int(np.argmax(raw_predictions))
        confidence_percentage = round(float(raw_predictions[best_index]) * 100.0, 2)
        predicted_class = CLASSES[best_index]

        all_scores = {
            CLASSES[i]: round(float(raw_predictions[i]) * 100.0, 2)
            for i in range(len(CLASSES))
        }

        if confidence_percentage < CONFIDENCE_THRESHOLD:
            return {
                "class": "Object not confidently identified.",
                "confidence": confidence_percentage,
                "recommendation": RECOMMENDATIONS["Low Confidence"],
                "all_scores": all_scores,
                "status": "low_confidence",
                "message": "Unable to confidently identify this waste. Please upload a clearer image."
            }

        return {
            "class": predicted_class,
            "confidence": confidence_percentage,
            "recommendation": RECOMMENDATIONS.get(predicted_class, "Send the material for appropriate steel recycling/reprocessing."),
            "all_scores": all_scores,
            "status": "success"
        }

    except Exception as e:
        return {
            "class": "Error",
            "confidence": 0.0,
            "recommendation": "Error occurred during processing.",
            "error": str(e),
            "status": "error"
        }


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        test_path = sys.argv[1]
        print(f"Testing prediction on: {test_path}")
        result = predict_image(test_path)
        print("Result:", result)
    else:
        print("Usage: python predict.py <path_to_image>")

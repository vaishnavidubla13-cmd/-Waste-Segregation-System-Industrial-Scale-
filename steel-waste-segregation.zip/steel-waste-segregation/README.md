# Image-Based Steel Industry Waste Segregation System Using Machine Learning
*(With Live Camera-Based Waste Identification)*

**Academic Level:** Second-Year B.Tech Mini Project  
**Domain:** Artificial Intelligence & Computer Vision in Industrial Automation  
**Base Architecture:** MobileNetV2 (Transfer Learning with ImageNet Pre-trained Weights)  
**Backend Framework:** Python Flask & OpenCV  
**Frontend Stack:** HTML5, CSS3, JavaScript (Webcam API), Bootstrap 5  

---

## 1. Project Overview & Two Operational Modes

This academic mini project develops an intelligent steel-industry waste identification system offering two modes:

### **Option 1: Upload Waste Image**
* Upload existing photos (.jpg, .jpeg, .png) from a computer or mobile storage.
* Inspect image preview, downsample to 224 × 224, and classify into target scrap categories.

### **Option 2: Live Waste Detection (Webcam)**
* Continuous real-time identification using the computer's webcam via `navigator.mediaDevices.getUserMedia()`.
* Throttled frame sampling (1 to 2 frames per second) to prevent backend server bottlenecks.
* Rectangular guide box: *"Place one waste item inside the box"*.
* On-screen HUD overlay showing predicted category, confidence score, and industrial recycling recommendation.
* Confidence gating: If confidence < 60%, the screen displays *"Object not confidently identified."*

---

## 2. Waste Classes & Predefined Recommendations

1. **Steel Scrap:**  
   *Recommendation:* *"Send the material for appropriate steel recycling/reprocessing."*
2. **Metal Turnings/Chips:**  
   *Recommendation:* *"Collect separately and send for metal recycling/recovery."*
3. **Other Waste:**  
   *Recommendation:* *"Separate manually and dispose of according to the material type."*
4. **Low Confidence (< 60%):**  
   *Display:* *"Object not confidently identified."*  
   *Recommendation:* *"Unable to identify. Ensure one waste item is clearly placed inside the guide box."*

---

## 3. Live Camera System Architecture

```text
  [ Computer Webcam Stream ]
              │
              ▼
  [ Browser HTML5 <video> Element ]
              │ (Periodic capture: 1 - 2 FPS)
              ▼
  [ HTML5 <canvas> (224 × 224 Resizing) ]
              │
              ▼ (POST /predict_frame as base64 JPEG)
  [ Flask Backend (app.py) ]
              │
              ▼
  [ OpenCV / NumPy Array Decoding ]
              │
              ▼
  [ MobileNetV2 Preprocessing: scale to [-1, 1] ]
              │
              ▼
  [ MobileNetV2 Softmax Classifier (3 Classes) ]
              │
              ▼
  [ JSON Response ] ──► Update Camera HUD & Result Panel:
                        • Waste: STEEL SCRAP
                        • Confidence: 94%
                        • Recommendation: "Send material for recycling."
```

---

## 4. Important Project Limitation

> **Important Limitation for Evaluation:**  
> This system is built using an **Image-Classification** model (MobileNetV2), which predicts a single category for the overall field of view. It is **not an object-detection model** (such as YOLO) that places bounding boxes around multiple objects simultaneously.  
> **Operational Guideline:** Always place **one waste item inside the rectangular guide box at a time**.

---

## 5. Directory Structure

```text
steel-waste-segregation/
│
├── app.py                      # Flask server serving Option 1 (/) and Option 2 (/camera)
├── train_model.py              # MobileNetV2 transfer learning training pipeline
├── predict.py                  # Prediction module for file paths and camera frames
├── dataset_setup.py            # Directory setup and synthetic test sample generator
├── requirements.txt            # Python dependencies (Flask, TensorFlow, OpenCV, etc.)
├── README.md                   # Complete academic documentation and viva preparation
│
├── model/
│   └── steel_waste_model.keras # Saved Keras model file
│
├── dataset/
│   ├── train/
│   ├── validation/
│   └── test/
│
├── static/
│   ├── css/
│   │   └── style.css           # Industrial styling, camera guide box, and HUD overlay
│   └── js/
│       ├── main.js             # Upload mode controller (Option 1)
│       └── camera.js           # Live webcam controller and 1-2 FPS sampler (Option 2)
│
└── templates/
    ├── index.html              # Option 1: Upload Waste Image page
    └── camera.html             # Option 2: Live Waste Detection page
```

---

## 6. How to Run Locally in VS Code (Step-by-Step)

Follow these exact steps to run the complete system on your laptop using Visual Studio Code:

### Step 1: Open VS Code
1. Launch **Visual Studio Code**.
2. Go to **File -> Open Folder...** and select the `steel-waste-segregation` directory.

### Step 2: Open the Integrated Terminal
* Press `` Ctrl + ` `` (backtick) or select **Terminal -> New Terminal** from the top menu.

### Step 3: Create & Activate a Python Virtual Environment
**On Windows (PowerShell or Command Prompt):**
```bash
python -m venv venv
venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```
*(You will see `(venv)` appear at the start of your terminal line).*

### Step 4: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5: (First Time Only) Generate Dataset & Train Model
```bash
python dataset_setup.py
python train_model.py
```
*(This trains MobileNetV2 and saves `model/steel_waste_model.keras`).*

### Step 6: Start the Flask Application
```bash
python app.py
```
*Output will display:*
```text
=================================================================
  Steel Industry Waste Segregation System - Flask Server
  Option 1: Upload Image     -> http://127.0.0.1:5000/
  Option 2: Live Camera Feed -> http://127.0.0.1:5000/camera
=================================================================
 * Running on http://127.0.0.1:5000
```

### Step 7: Open in Your Browser
* **Option 1 (Upload Mode):** Navigate to [http://127.0.0.1:5000/](http://127.0.0.1:5000/)
* **Option 2 (Live Webcam):** Navigate to [http://127.0.0.1:5000/camera](http://127.0.0.1:5000/camera)
* Click **"Start Camera"** and allow your browser camera permission. Place a piece of metal, scrap, or waste inside the dashed guide box to observe live predictions!

---

## 7. Viva Voce Preparation for External Examination

**Q: How does the system handle webcam frames without overwhelming the backend?**  
*Answer:* The client-side JavaScript (`camera.js`) samples video frames at approximately 1 to 2 frames per second using an HTML5 `<canvas>` element scaled directly to 224 × 224 pixels. It sends only these downsampled frames via asynchronous `fetch` calls to `/predict_frame`, ensuring the Flask server runs inference smoothly without dropping frames or queuing network backlog.

**Q: Why is there a rectangular guide box on the camera screen?**  
*Answer:* Because MobileNetV2 performs whole-image classification rather than bounding-box object detection. The guide box helps the user center one target object at a time and avoid background clutter that could dilute classification confidence.

**Q: What happens if an unrelated or blurry object is held in front of the camera?**  
*Answer:* The Softmax output layer produces probabilities for all three classes. If the highest class probability is under the 60% confidence threshold, the HUD displays *"Object not confidently identified."* to prevent false industrial sorting decisions.

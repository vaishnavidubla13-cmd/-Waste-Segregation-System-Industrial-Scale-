"""
dataset_setup.py
----------------
Dataset Preparation and Directory Setup Script for:
"Image-Based Steel Industry Waste Segregation System Using Machine Learning"

References and Datasets included:
1. Nature Scientific Data (2023): A dataset of metal scrap images for recycling
   URL: https://www.nature.com/articles/s41597-023-02662-6
2. Zenodo Metal Scrap Repository:
   URL: https://zenodo.org/records/8219163
   URL: https://zenodo.org/records/20271102
3. Roboflow Universe Steel Scrap Datasets:
   URL: https://universe.roboflow.com/dogan-bakir/steel-scrap-sowop-i0pwl
   URL: https://universe.roboflow.com/the-scrap-mart/steel-scrap-sowop-zond0
4. Mendeley Data Steel Waste:
   URL: https://data.mendeley.com/datasets/ch34f38kz5/1
5. Kaggle Severstal Steel Defect Dataset:
   URL: https://www.kaggle.com/competitions/severstal-steel-defect-detection/data

Run this script to:
1. Create all train/val/test directories.
2. Generate initial sample benchmark images so you can test-run train_model.py right away.
3. Print guide for downloading full datasets from Nature/Zenodo/Roboflow.
"""

import os
import math
import random
import numpy as np
from PIL import Image, ImageDraw

CLASSES = ["Steel Scrap", "Metal Turnings", "Other Waste"]
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")


def setup_directories():
    """
    Creates standard ImageNet / Keras directory structure:
      dataset/
        ├── train/
        │   ├── Steel Scrap/
        │   ├── Metal Turnings/
        │   └── Other Waste/
        ├── validation/
        │   ├── Steel Scrap/
        │   ├── Metal Turnings/
        │   └── Other Waste/
        └── test/
            ├── Steel Scrap/
            ├── Metal Turnings/
            └── Other Waste/
    """
    splits = ["train", "validation", "test"]
    for split in splits:
        for cls in CLASSES:
            folder_path = os.path.join(DATASET_DIR, split, cls)
            os.makedirs(folder_path, exist_ok=True)
            
    os.makedirs(os.path.join(BASE_DIR, "model"), exist_ok=True)
    os.makedirs(os.path.join(BASE_DIR, "uploads"), exist_ok=True)
    print(f"[+] Verified and created dataset directories at: {DATASET_DIR}")


def generate_benchmark_synthetic_sample(class_name, index, output_path):
    """
    Generates realistic procedural visual samples for testing the training pipeline
    prior to downloading multi-gigabyte external datasets.
    """
    width, height = 224, 224
    
    if class_name == "Steel Scrap":
        # Steel Scrap: Heavy metallic gray/slate/rust background, angular cut-outs, heavy beams/plates
        base_color = random.choice([(110, 115, 125), (95, 100, 110), (140, 110, 90)])
        img = Image.new("RGB", (width, height), color=base_color)
        draw = ImageDraw.Draw(img)
        # Add metallic plates / sheared structural bars
        for _ in range(random.randint(6, 12)):
            x1, y1 = random.randint(10, 180), random.randint(10, 180)
            x2, y2 = x1 + random.randint(30, 120), y1 + random.randint(30, 100)
            plate_color = random.choice([
                (70, 75, 82), (160, 165, 175), (130, 80, 50), (90, 95, 105)
            ])
            draw.rectangle([x1, y1, x2, y2], fill=plate_color, outline=(40, 40, 45), width=2)
            # Add weld lines / rust spots
            draw.line([(x1, y1), (x2, y2)], fill=(150, 75, 40), width=random.randint(1, 3))

    elif class_name == "Metal Turnings":
        # Metal Turnings/Chips: High-frequency spirals, curly swarf, brass/steel spiral shavings
        img = Image.new("RGB", (width, height), color=(45, 48, 52))
        draw = ImageDraw.Draw(img)
        # Draw coiled metallic ribbons and lathe shavings
        for _ in range(random.randint(25, 45)):
            start_x, start_y = random.randint(20, 200), random.randint(20, 200)
            points = []
            radius = random.uniform(8, 22)
            shaving_color = random.choice([
                (190, 195, 205), (210, 180, 100), (150, 155, 165), (230, 230, 240)
            ])
            for t in range(0, 360, 25):
                rad = math.radians(t)
                px = start_x + (radius + t * 0.05) * math.cos(rad)
                py = start_y + (radius + t * 0.05) * math.sin(rad)
                points.append((px, py))
            if len(points) > 2:
                draw.line(points, fill=shaving_color, width=random.randint(2, 3))

    else:
        # Other Waste: Wooden pallet slats, blue plastic wraps, cardboard, industrial rubble
        img = Image.new("RGB", (width, height), color=(180, 160, 130))
        draw = ImageDraw.Draw(img)
        for _ in range(random.randint(5, 10)):
            x1, y1 = random.randint(10, 160), random.randint(10, 160)
            w, h = random.randint(40, 120), random.randint(30, 80)
            waste_color = random.choice([
                (165, 120, 80),   # Wood
                (35, 110, 190),   # Blue plastic barrel/tarp
                (200, 190, 150),  # Cardboard
                (80, 85, 75)      # Dirt / rubble
            ])
            draw.rectangle([x1, y1, x1 + w, y1 + h], fill=waste_color, outline=(30, 30, 30))

    img.save(output_path, "JPEG", quality=90)


def create_starter_dataset():
    """
    Populates sample images in train and validation folders so students
    can test `python train_model.py` out-of-the-box without waiting.
    """
    counts = {"train": 20, "validation": 6, "test": 4}
    print("[*] Generating starter benchmark samples for offline testing...")
    
    for split, count in counts.items():
        for cls in CLASSES:
            folder = os.path.join(DATASET_DIR, split, cls)
            for i in range(1, count + 1):
                filename = f"{cls.lower().replace(' ', '_')}_{split}_{i:03d}.jpg"
                file_path = os.path.join(folder, filename)
                generate_benchmark_synthetic_sample(cls, i, file_path)
                
    print("[+] Starter dataset generated successfully!")


def print_dataset_sources_guide():
    """
    Prints download guide for real-world academic research datasets provided by user.
    """
    print("\n" + "=" * 70)
    print("  ACADEMIC DATASET DOWNLOAD & CITATION GUIDE")
    print("=" * 70)
    print("""
1. Nature Scientific Data (2023)
   - Title: 'A dataset of metal scrap images for deep learning-based recycling'
   - Link:  https://www.nature.com/articles/s41597-023-02662-6
   - Use:   High-resolution industrial scrap and metal classification benchmark.

2. Zenodo Research Repositories
   - Record 8219163:  https://zenodo.org/records/8219163
   - Record 20271102: https://zenodo.org/records/20271102
   - Contains thousands of sorted metal scrap, turnings, and industrial waste.

3. Roboflow Universe (Annotated Steel Scrap)
   - Dataset 1: https://universe.roboflow.com/dogan-bakir/steel-scrap-sowop-i0pwl
   - Dataset 2: https://universe.roboflow.com/the-scrap-mart/steel-scrap-sowop-zond0
   - How to download:
     curl -L "https://universe.roboflow.com/ds/YOUR_KEY" > roboflow.zip && unzip roboflow.zip

4. Mendeley Data
   - Link: https://data.mendeley.com/datasets/ch34f38kz5/1
   - Contains structural steel defect and manufacturing scrap images.

5. Kaggle Severstal Steel Defect Detection
   - Link: https://www.kaggle.com/competitions/severstal-steel-defect-detection/data
   - Useful for steel surface textures, slag, and manufacturing anomalies.
""")
    print("=" * 70)


if __name__ == "__main__":
    setup_directories()
    create_starter_dataset()
    print_dataset_sources_guide()

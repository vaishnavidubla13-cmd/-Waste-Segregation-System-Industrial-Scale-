"""
train_model.py
--------------
Training script for the Image-Based Steel Industry Waste Segregation System.
Uses MobileNetV2 Transfer Learning on 224x224 input images.

Academic Level: Second-Year B.Tech Mini Project
Target Model Architecture:
  Input (224x224x3)
    ↓
  Data Augmentation (Flip, Rotation, Zoom)
    ↓
  MobileNetV2 Base (Pre-trained on ImageNet, Frozen)
    ↓
  GlobalAveragePooling2D
    ↓
  Dropout (0.2)
    ↓
  Dense (3 units, Softmax Activation)

Saves trained model to: model/steel_waste_model.keras
"""

import os
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

# 1. Hyperparameters and Directory Paths
IMAGE_SIZE = (224, 224)
BATCH_SIZE = 16
EPOCHS = 15
LEARNING_RATE = 0.0005
NUM_CLASSES = 3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
TRAIN_DIR = os.path.join(DATASET_DIR, "train")
VAL_DIR = os.path.join(DATASET_DIR, "validation")
MODEL_DIR = os.path.join(BASE_DIR, "model")
MODEL_SAVE_PATH = os.path.join(MODEL_DIR, "steel_waste_model.keras")

CLASS_NAMES = ["Steel Scrap", "Metal Turnings", "Other Waste"]


def prepare_datasets():
    """
    Loads images from dataset/train and dataset/validation using
    tf.keras.utils.image_dataset_from_directory.
    Applies MobileNetV2 preprocessing and prefetching for optimal GPU/CPU efficiency.
    """
    print(f"[*] Checking dataset directories...")
    if not os.path.exists(TRAIN_DIR) or not os.path.exists(VAL_DIR):
        raise FileNotFoundError(
            f"Dataset directories not found!\n"
            f"Expected: {TRAIN_DIR} and {VAL_DIR}\n"
            f"Please run 'python dataset_setup.py' to initialize the dataset folders or download dataset samples."
        )

    print(f"[*] Loading training dataset from {TRAIN_DIR}...")
    train_ds = tf.keras.utils.image_dataset_from_directory(
        TRAIN_DIR,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="categorical",
        shuffle=True,
        seed=42
    )

    print(f"[*] Loading validation dataset from {VAL_DIR}...")
    val_ds = tf.keras.utils.image_dataset_from_directory(
        VAL_DIR,
        image_size=IMAGE_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="categorical",
        shuffle=False
    )

    detected_classes = train_ds.class_names
    print(f"[+] Detected classes in folder: {detected_classes}")

    # Optimize pipeline with caching and prefetching
    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

    return train_ds, val_ds, detected_classes


def build_transfer_learning_model(num_classes=3):
    """
    Builds the classification model using MobileNetV2 as a frozen feature extractor.
    
    Why MobileNetV2 for B.Tech Mini Project?
    - Lightweight (~2.2M base parameters vs 25M+ for ResNet50).
    - Fast training even on standard laptop CPUs.
    - High accuracy due to inverted residual blocks with depthwise separable convolutions.
    - Pre-trained on 1.4 million ImageNet images, learning universal edges, textures, and shapes.
    """
    # 1. Input Layer
    inputs = tf.keras.Input(shape=(224, 224, 3), name="input_image")

    # 2. Data Augmentation to prevent overfitting on small datasets
    data_augmentation = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.15),
        layers.RandomZoom(0.15),
        layers.RandomContrast(0.1)
    ], name="data_augmentation")
    
    x = data_augmentation(inputs)

    # 3. MobileNetV2 Preprocessing Layer: scales [0, 255] to [-1, 1]
    x = preprocess_input(x)

    # 4. Pre-trained Base Model (ImageNet weights, exclude top dense classifier)
    base_model = MobileNetV2(
        input_shape=(224, 224, 3),
        include_top=False,
        weights="imagenet"
    )
    
    # Freeze the base model to preserve learned ImageNet features
    base_model.trainable = False
    
    x = base_model(x, training=False)

    # 5. Classification Head
    # GlobalAveragePooling2D reduces spatial dimensions (7x7x1280) to a 1D vector (1280)
    x = layers.GlobalAveragePooling2D(name="global_avg_pool")(x)
    
    # Dropout prevents co-adaptation of features
    x = layers.Dropout(0.2, name="dropout_layer")(x)
    
    # Dense Softmax layer outputs probabilities across our 3 waste classes
    outputs = layers.Dense(num_classes, activation="softmax", name="waste_classifier")(x)

    model = models.Model(inputs=inputs, outputs=outputs, name="SteelWasteSegregationModel")
    return model, base_model


def train():
    """
    Main training routine:
    1. Loads datasets
    2. Builds model
    3. Compiles with Adam optimizer and Categorical Crossentropy
    4. Trains for specified epochs with EarlyStopping
    5. Evaluates accuracy
    6. Saves .keras model file
    7. Plots loss and accuracy curves
    """
    os.makedirs(MODEL_DIR, exist_ok=True)
    
    train_ds, val_ds, class_names = prepare_datasets()
    model, base_model = build_transfer_learning_model(num_classes=len(class_names))

    # Compile the model
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )

    print("\n" + "=" * 60)
    print("MODEL ARCHITECTURE SUMMARY:")
    print("=" * 60)
    model.summary()

    # Callbacks
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=5,
            restore_best_weights=True,
            verbose=1
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=3,
            verbose=1
        )
    ]

    print("\n[*] Starting training MobileNetV2 on Steel Waste dataset...")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=EPOCHS,
        callbacks=callbacks
    )

    # Evaluate final accuracy
    val_loss, val_acc = model.evaluate(val_ds, verbose=0)
    print("\n" + "=" * 60)
    print(f"[+] Final Validation Accuracy: {val_acc * 100:.2f}%")
    print(f"[+] Final Validation Loss:     {val_loss:.4f}")
    print("=" * 60)

    # Save trained model
    print(f"[*] Saving trained model to {MODEL_SAVE_PATH}...")
    model.save(MODEL_SAVE_PATH)
    print(f"[+] Successfully saved model to {MODEL_SAVE_PATH}")

    # Plot & Save Accuracy/Loss graph for project report
    plot_training_curves(history)


def plot_training_curves(history):
    """
    Generates and saves accuracy & loss curves for student project documentation.
    """
    acc = history.history.get("accuracy", [])
    val_acc = history.history.get("val_accuracy", [])
    loss = history.history.get("loss", [])
    val_loss = history.history.get("val_loss", [])

    epochs_range = range(1, len(acc) + 1)

    plt.figure(figsize=(12, 5))

    # Subplot 1: Accuracy
    plt.subplot(1, 2, 1)
    plt.plot(epochs_range, acc, label="Training Accuracy", color="#0284c7", lw=2)
    plt.plot(epochs_range, val_acc, label="Validation Accuracy", color="#10b981", lw=2)
    plt.title("Model Accuracy over Epochs", fontsize=13, fontweight="bold")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.legend(loc="lower right")
    plt.grid(True, linestyle="--", alpha=0.5)

    # Subplot 2: Loss
    plt.subplot(1, 2, 2)
    plt.plot(epochs_range, loss, label="Training Loss", color="#ef4444", lw=2)
    plt.plot(epochs_range, val_loss, label="Validation Loss", color="#f59e0b", lw=2)
    plt.title("Categorical Crossentropy Loss", fontsize=13, fontweight="bold")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend(loc="upper right")
    plt.grid(True, linestyle="--", alpha=0.5)

    plot_path = os.path.join(MODEL_DIR, "training_history.png")
    plt.tight_layout()
    plt.savefig(plot_path, dpi=200)
    plt.close()
    print(f"[+] Training curves saved to: {plot_path}")


if __name__ == "__main__":
    train()

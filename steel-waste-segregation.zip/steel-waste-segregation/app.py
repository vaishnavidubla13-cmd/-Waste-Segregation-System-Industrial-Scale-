"""
app.py
------
Flask Web Application for:
"Image-Based Steel Industry Waste Segregation System Using Machine Learning"
with Live Camera-Based Waste Identification.

Academic Level: Second-Year B.Tech Mini Project

Routes:
  - GET  /              : Option 1 - Upload Waste Image (templates/index.html)
  - GET  /camera        : Option 2 - Live Waste Detection (templates/camera.html)
  - POST /predict       : Single image upload classification
  - POST /predict_frame : Live webcam periodic frame classification (1-3 FPS)
"""

import os
import uuid
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
from predict import predict_image, predict_base64_frame, predict_frame

# Initialize Flask application
app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)

# Configuration
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/", methods=["GET"])
def index():
    """
    Renders Option 1: Upload Image interface.
    """
    return render_template("index.html")


@app.route("/camera", methods=["GET"])
def camera_page():
    """
    Renders Option 2: Live Camera Waste Detection interface.
    """
    return render_template("camera.html")


@app.route("/predict", methods=["POST"])
def predict():
    """
    Endpoint for Option 1: File upload classification.
    """
    if "image" not in request.files and "file" not in request.files:
        return jsonify({"error": "No file uploaded. Please upload a waste image."}), 400

    file = request.files.get("image") or request.files.get("file")

    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid format. Only .jpg, .jpeg, .png allowed."}), 400

    temp_filepath = None
    try:
        unique_name = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
        temp_filepath = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
        file.save(temp_filepath)

        result = predict_image(temp_filepath)

        return jsonify({
            "class": result.get("class", "Object not confidently identified."),
            "confidence": result.get("confidence", 0.0),
            "recommendation": result.get("recommendation", "Separate according to material type."),
            "status": result.get("status", "success")
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        if temp_filepath and os.path.exists(temp_filepath):
            try:
                os.remove(temp_filepath)
            except OSError:
                pass


@app.route("/predict_frame", methods=["POST"])
def predict_frame_endpoint():
    """
    Endpoint for Option 2: Live Camera Frame Classification.
    Accepts JSON payload: { "frame": "data:image/jpeg;base64,..." }
    Or multipart form data with 'frame' image file.
    
    Returns:
    {
      "class": "Steel Scrap",
      "confidence": 94.21,
      "recommendation": "Send the material for appropriate steel recycling."
    }
    """
    try:
        # Check if JSON payload with base64 data
        if request.is_json:
            data = request.get_json()
            frame_data = data.get("frame")
            if not frame_data:
                return jsonify({"error": "No frame data found in JSON payload."}), 400
            
            result = predict_base64_frame(frame_data)
            return jsonify({
                "class": result.get("class", "Object not confidently identified."),
                "confidence": result.get("confidence", 0.0),
                "recommendation": result.get("recommendation", "Unable to identify. Ensure waste item is clearly placed inside the guide box."),
                "status": result.get("status", "success")
            }), 200

        # Check if multipart form upload
        elif "frame" in request.files or "image" in request.files:
            file = request.files.get("frame") or request.files.get("image")
            unique_name = f"frame_{uuid.uuid4().hex}.jpg"
            temp_filepath = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
            file.save(temp_filepath)

            try:
                result = predict_image(temp_filepath)
                return jsonify({
                    "class": result.get("class", "Object not confidently identified."),
                    "confidence": result.get("confidence", 0.0),
                    "recommendation": result.get("recommendation", "Process according to material type."),
                    "status": result.get("status", "success")
                }), 200
            finally:
                if os.path.exists(temp_filepath):
                    try:
                        os.remove(temp_filepath)
                    except OSError:
                        pass

        else:
            return jsonify({"error": "Missing camera frame in request."}), 400

    except Exception as e:
        return jsonify({
            "error": "Server error while classifying camera frame.",
            "details": str(e)
        }), 500


@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "online",
        "project": "Image-Based Steel Industry Waste Segregation System",
        "features": ["Option 1: Upload Image", "Option 2: Live Camera Detection"],
        "endpoints": ["/predict", "/predict_frame"]
    })


if __name__ == "__main__":
    print("=" * 65)
    print("  Steel Industry Waste Segregation System - Flask Server")
    print("  Second-Year B.Tech Mini Project")
    print("  Option 1: Upload Image      -> http://127.0.0.1:5000/")
    print("  Option 2: Live Camera Feed  -> http://127.0.0.1:5000/camera")
    print("=" * 65)
    app.run(host="0.0.0.0", port=5000, debug=True)

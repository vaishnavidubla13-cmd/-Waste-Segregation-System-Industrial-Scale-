export type WasteClass = 'Steel Scrap' | 'Metal Turnings' | 'Other Waste' | 'Unknown / Low Confidence';

export interface ClassificationResult {
  class: WasteClass;
  confidence: number; // 0 to 100
  recommendation: string;
  status: 'success' | 'low_confidence' | 'error';
  allScores: {
    'Steel Scrap': number;
    'Metal Turnings': number;
    'Other Waste': number;
  };
  metrics?: {
    metalReflectance: number;
    textureSwarfDensity: number;
    rustIronTone: number;
    nonMetalOrganicIndex: number;
    resolution: string;
  };
  processingTimeMs: number;
}

export interface SampleImage {
  id: string;
  name: string;
  category: WasteClass;
  description: string;
  dataUrl: string;
  expectedConfidence: number;
}

export interface ProjectFile {
  filename: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export interface VivaQuestion {
  question: string;
  answer: string;
  category: 'Machine Learning' | 'Preprocessing' | 'Industrial Application' | 'System Architecture';
}

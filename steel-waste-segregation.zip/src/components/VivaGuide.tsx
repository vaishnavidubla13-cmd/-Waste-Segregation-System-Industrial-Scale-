import React from 'react';
import { HelpCircle, ChevronRight, Award } from 'lucide-react';
import { VIVA_QUESTIONS } from '../data/projectFiles';

export const VivaGuide: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Title Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-600 mb-1">
          <Award className="w-4 h-4" />
          Academic Evaluation Preparation
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
          Second-Year B.Tech Viva Voce Q&A Guide
        </h2>
        <p className="text-slate-600 text-sm leading-relaxed">
          Standard questions asked by external examiners and university project evaluators regarding model selection, convolutional neural network mechanics, data preprocessing, and industrial feasibility.
        </p>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {VIVA_QUESTIONS.map((item, idx) => (
          <div
            key={idx}
            className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs"
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <span className="text-xs font-bold font-mono text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200 shrink-0">
                Q{idx + 1}
              </span>
              <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide">
                Category: {item.category}
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900 mb-3">
              {item.question}
            </h3>

            <div className="p-4 rounded-lg bg-slate-50 border border-slate-100 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <strong className="text-slate-900 block mb-1">Model Answer for Evaluation:</strong>
              {item.answer}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

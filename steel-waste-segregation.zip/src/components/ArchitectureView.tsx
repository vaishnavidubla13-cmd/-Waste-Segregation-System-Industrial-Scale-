import React from 'react';
import { Cpu, ArrowDown, Layers, CheckCircle2 } from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const layersList = [
    {
      name: 'Input Layer',
      shape: '(None, 224, 224, 3)',
      desc: 'Raw RGB waste image tensor formatted to standard MobileNetV2 dimensions.',
      color: 'bg-slate-800 text-white'
    },
    {
      name: 'Data Augmentation',
      shape: '(None, 224, 224, 3)',
      desc: 'RandomFlip("horizontal"), RandomRotation(0.15), RandomZoom(0.15) to prevent overfitting.',
      color: 'bg-sky-700 text-white'
    },
    {
      name: 'MobileNetV2 Preprocessing',
      shape: '(None, 224, 224, 3)',
      desc: 'Scales raw uint8 [0, 255] pixels to normalized float32 in range [-1.0, +1.0].',
      color: 'bg-blue-600 text-white'
    },
    {
      name: 'MobileNetV2 Base (Feature Extractor)',
      shape: '(None, 7, 7, 1280)',
      desc: '53 inverted residual bottleneck layers pre-trained on 1.4M ImageNet images. Frozen weights during transfer learning.',
      color: 'bg-indigo-600 text-white',
      badge: 'Frozen Base (~2.2M params)'
    },
    {
      name: 'GlobalAveragePooling2D',
      shape: '(None, 1280)',
      desc: 'Calculates the spatial average across each 7×7 feature map. Prevents parameter explosion compared to Flatten.',
      color: 'bg-teal-600 text-white'
    },
    {
      name: 'Dropout (Rate = 0.2)',
      shape: '(None, 1280)',
      desc: 'Randomly drops 20% of activations during training to discourage co-adaptation of features.',
      color: 'bg-amber-600 text-white'
    },
    {
      name: 'Dense Softmax Classifier',
      shape: '(None, 3)',
      desc: '3 output nodes with Softmax activation function yielding probabilities for Steel Scrap, Metal Turnings, and Other Waste.',
      color: 'bg-emerald-600 text-white',
      badge: 'Trainable Head (3,843 params)'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Title Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-600 mb-1">
          <Cpu className="w-4 h-4" />
          Transfer Learning Architecture
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
          MobileNetV2 Convolutional Neural Network
        </h2>
        <p className="text-slate-600 text-sm leading-relaxed">
          For a second-year B.Tech mini project, training a high-parameter network (like ResNet or VGG) from scratch is impractical due to dataset size and hardware constraints. We apply <strong>Transfer Learning</strong> using Google's MobileNetV2 architecture with pre-trained ImageNet weights.
        </p>
      </div>

      {/* Layer Stack Diagram */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <h3 className="text-base font-bold text-slate-900 mb-6 flex items-center justify-between">
          <span>Sequential Processing Pipeline</span>
          <span className="text-xs font-medium text-slate-500">Image → Prediction</span>
        </h3>

        <div className="space-y-3">
          {layersList.map((layer, idx) => (
            <React.Fragment key={layer.name}>
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3">
                  <span className={`px-2.5 py-1 rounded text-xs font-bold font-mono ${layer.color}`}>
                    L{idx + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 text-sm">{layer.name}</h4>
                      {layer.badge && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-800">
                          {layer.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{layer.desc}</p>
                  </div>
                </div>

                <div className="sm:text-right shrink-0">
                  <span className="text-[11px] text-slate-600 block">Tensor Shape</span>
                  <span className="text-xs font-mono font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                    {layer.shape}
                  </span>
                </div>
              </div>

              {idx < layersList.length - 1 && (
                <div className="flex justify-center my-0.5 text-slate-400">
                  <ArrowDown className="w-4 h-4" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Technical Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs">
          <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-sm mb-3">
            01
          </div>
          <h4 className="font-bold text-slate-900 text-sm mb-1">Depthwise Separable Convolutions</h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            Factorizes standard convolutions into a depthwise convolution followed by a 1×1 pointwise convolution, cutting computation by 8× to 9× with negligible accuracy drop.
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs">
          <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm mb-3">
            02
          </div>
          <h4 className="font-bold text-slate-900 text-sm mb-1">Inverted Residual Blocks</h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            Expands to a higher-dimensional representation, performs depthwise convolution, and projects back to low dimension with linear bottleneck skip connections.
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-200 bg-white shadow-xs">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm mb-3">
            03
          </div>
          <h4 className="font-bold text-slate-900 text-sm mb-1">Softmax Multi-Class Activation</h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            Computes a normalized probability distribution across the 3 output classes where probabilities sum to 1.0, enabling strict threshold gating at 60%.
          </p>
        </div>
      </div>
    </div>
  );
};

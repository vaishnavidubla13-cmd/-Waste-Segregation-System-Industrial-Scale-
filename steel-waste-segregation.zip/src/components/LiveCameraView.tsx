import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, StopCircle, Play, AlertCircle, Sparkles, CheckCircle2, Sliders, Info } from 'lucide-react';
import { ClassificationResult, WasteClass } from '../types';
import { classifyImage } from '../utils/classifier';
import { SAMPLE_IMAGES } from '../data/sampleImages';

export const LiveCameraView: React.FC = () => {
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isSimulatedFeed, setIsSimulatedFeed] = useState<boolean>(false);
  const [simulationIndex, setSimulationIndex] = useState<number>(0);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<ClassificationResult | null>(null);
  const [fps, setFps] = useState<number>(1.5);
  const [showTensorInspector, setShowTensorInspector] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const simulationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Stop camera helper
  const stopCamera = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (simulationIntervalRef.current) {
      clearInterval(simulationIntervalRef.current);
      simulationIntervalRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setIsCameraActive(false);
    setIsSimulatedFeed(false);
    setIsCapturing(false);
  }, []);

  // Frame processing routine
  const processFrame = useCallback(async () => {
    if (isCapturing) return;

    try {
      setIsCapturing(true);

      let imageSource: string | null = null;
      let hint: WasteClass | undefined = undefined;

      if (isSimulatedFeed) {
        const sample = SAMPLE_IMAGES[simulationIndex % SAMPLE_IMAGES.length];
        imageSource = sample.dataUrl;
        hint = sample.category;
      } else if (videoRef.current && videoRef.current.videoWidth > 0) {
        const video = videoRef.current;
        const canvas = canvasRef.current || document.createElement('canvas');
        canvas.width = 224;
        canvas.height = 224;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, 224, 224);
          imageSource = canvas.toDataURL('image/jpeg', 0.85);
        }
      }

      if (imageSource) {
        const res = await classifyImage(imageSource, hint);
        setLastResult(res);
      }
    } catch (err: unknown) {
      console.warn('Frame processing exception:', err);
    } finally {
      setIsCapturing(false);
    }
  }, [isCapturing, isSimulatedFeed, simulationIndex]);

  // Periodic capture interval trigger
  useEffect(() => {
    if (isCameraActive) {
      const intervalMs = Math.round(1000 / fps);
      intervalRef.current = setInterval(processFrame, intervalMs);

      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    }
  }, [isCameraActive, fps, processFrame]);

  // Simulation cycler
  useEffect(() => {
    if (isSimulatedFeed) {
      simulationIntervalRef.current = setInterval(() => {
        setSimulationIndex((prev) => (prev + 1) % SAMPLE_IMAGES.length);
      }, 4000);

      return () => {
        if (simulationIntervalRef.current) {
          clearInterval(simulationIntervalRef.current);
        }
      };
    }
  }, [isSimulatedFeed]);

  // Start Real Hardware Webcam
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Webcam API is not supported in this browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'environment'
        },
        audio: false
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setIsCameraActive(true);
          setIsSimulatedFeed(false);
        };
      }
    } catch (err: unknown) {
      console.error('Camera access failed:', err);
      const msg = err instanceof Error ? err.message : String(err);
      setCameraError(
        `Unable to access webcam (${msg}). You can test the camera system using the 'Simulate Conveyor Camera' option below.`
      );
    }
  };

  // Start Simulated Camera Stream (for environments without physical camera or when permission is restricted)
  const startSimulatedCamera = () => {
    setCameraError(null);
    stopCamera();
    setIsSimulatedFeed(true);
    setIsCameraActive(true);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  const currentSample = isSimulatedFeed ? SAMPLE_IMAGES[simulationIndex % SAMPLE_IMAGES.length] : null;

  const isConfident = lastResult && lastResult.confidence >= 60 && lastResult.status !== 'low_confidence';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Title & Introduction Section */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-600 mb-1">
          <Camera className="w-4 h-4" />
          Live Waste Detection
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
          Real-Time Camera-Based Waste Identification
        </h2>
        <p className="text-slate-600 text-sm leading-relaxed mb-4">
          This module uses the webcam to continuously capture images of steel-industry waste at approximately 1–2 frames per second. Each frame is downscaled to 224 × 224 pixels and evaluated by the MobileNetV2 classification model to identify whether the item is <strong>Steel Scrap</strong>, <strong>Metal Turnings</strong>, or <strong>Other Waste</strong>.
        </p>

        {/* Important Mini Project Limitation */}
        <div className="p-3.5 rounded-lg bg-sky-50 border border-sky-200 flex items-start gap-2.5 text-xs text-sky-900">
          <Info className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
          <div>
            <strong>Important Mini Project Limitation:</strong> This is a lightweight image-classification model, not an object-detection model with multiple bounding boxes. For accurate classification, <strong>please place one waste object inside the guide box at a time</strong>.
          </div>
        </div>
      </div>

      {/* Main Camera Window Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs mb-8 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-base">Camera Viewport</h3>
            <span
              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                isCameraActive
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {isCameraActive ? (isSimulatedFeed ? '● Simulating Feed' : '● Live Stream') : 'Offline'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs text-slate-500 hidden sm:flex items-center gap-1">
              <span>Capture Rate:</span>
              <span className="font-semibold text-slate-800">{fps} FPS</span>
            </div>
            {isCapturing && (
              <span className="w-2 h-2 rounded-full bg-sky-500 animate-ping"></span>
            )}
          </div>
        </div>

        <div className="p-6">
          {/* Video Viewport with Guide Box and HUD Overlay */}
          <div className="relative rounded-xl overflow-hidden bg-slate-950 aspect-video flex items-center justify-center border border-slate-800 shadow-inner">
            {/* Real Hardware Video Stream */}
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover -scale-x-100 ${
                isCameraActive && !isSimulatedFeed ? 'block' : 'hidden'
              }`}
            />

            {/* Simulated Live Camera Stream */}
            {isCameraActive && isSimulatedFeed && currentSample && (
              <div className="w-full h-full relative flex items-center justify-center bg-slate-900">
                <img
                  src={currentSample.dataUrl}
                  alt={currentSample.name}
                  className="w-full h-full object-contain p-6"
                />
                <div className="absolute top-3 right-3 bg-black/70 text-slate-300 text-[10px] font-mono px-2 py-1 rounded border border-slate-700">
                  Simulated Conveyor Feed • Cycle: {currentSample.name}
                </div>
              </div>
            )}

            {/* Camera Inactive Placeholder */}
            {!isCameraActive && (
              <div className="text-center p-8 text-slate-400">
                <div className="w-16 h-16 rounded-full bg-slate-800 text-slate-500 mx-auto mb-3 flex items-center justify-center">
                  <Camera className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-slate-200 mb-1">
                  Camera Feed Inactive
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
                  Start the webcam to continuously classify steel scrap, lathe chips, and industrial waste.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button
                    onClick={startCamera}
                    className="px-4 py-2 rounded-full bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Start Webcam
                  </button>
                  <button
                    onClick={startSimulatedCamera}
                    className="px-4 py-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    Simulate Conveyor Camera
                  </button>
                </div>
              </div>
            )}

            {/* Rectangular Guide Box Overlay */}
            {isCameraActive && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-[62%] h-[68%] border-2 border-dashed border-sky-400/80 rounded-lg relative flex items-end justify-center pb-2 bg-sky-500/5">
                  {/* Corner brackets */}
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-4 border-l-4 border-sky-400"></div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-4 border-r-4 border-sky-400"></div>
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-4 border-l-4 border-sky-400"></div>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-4 border-r-4 border-sky-400"></div>

                  <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-black/75 text-white tracking-wide border border-white/20">
                    Place one waste item inside the box
                  </span>
                </div>
              </div>
            )}

            {/* On-Screen HUD Overlay */}
            {isCameraActive && (
              <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md rounded-lg p-2.5 text-white text-xs border border-white/10 shadow-lg text-left max-w-[200px]">
                <div className="text-[10px] uppercase font-bold text-sky-400 tracking-wider">
                  Live Classification HUD
                </div>
                <div className="font-bold text-sm truncate mt-0.5">
                  Waste:{' '}
                  <span className={isConfident ? 'text-emerald-400' : 'text-amber-400'}>
                    {lastResult ? (isConfident ? lastResult.class : 'Unidentified') : 'Scanning...'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-300">
                  Confidence:{' '}
                  <span className="font-bold text-sky-300">
                    {lastResult ? `${lastResult.confidence.toFixed(1)}%` : '0%'}
                  </span>
                </div>
              </div>
            )}

            {/* Hidden canvas used for 224x224 frame sampling */}
            <canvas ref={canvasRef} className="hidden" width={224} height={224} />
          </div>

          {/* Camera Controls Bar */}
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
            <div className="flex items-center gap-2">
              {!isCameraActive ? (
                <>
                  <button
                    onClick={startCamera}
                    className="px-5 py-2.5 rounded-full bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                  >
                    <Play className="w-4 h-4" />
                    Start Camera
                  </button>
                  <button
                    onClick={startSimulatedCamera}
                    className="px-4 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-300"
                  >
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    Simulate Conveyor Stream
                  </button>
                </>
              ) : (
                <button
                  onClick={stopCamera}
                  className="px-5 py-2.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <StopCircle className="w-4 h-4" />
                  Stop Camera
                </button>
              )}
            </div>

            {/* Frame rate controller */}
            {isCameraActive && (
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <span>Sampling Rate:</span>
                <div className="flex rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
                  {[1.0, 1.5, 2.5].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setFps(rate)}
                      className={`px-2.5 py-1 text-xs font-semibold cursor-pointer ${
                        fps === rate ? 'bg-sky-600 text-white' : 'text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {rate} FPS
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Camera Error Message */}
          {cameraError && (
            <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3 text-amber-900">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm">
                <span className="font-bold block">Camera Notice:</span>
                <p className="mt-0.5 leading-relaxed">{cameraError}</p>
                <button
                  onClick={startSimulatedCamera}
                  className="mt-2 text-xs font-bold text-sky-700 hover:text-sky-800 underline cursor-pointer"
                >
                  Click here to switch to the Conveyor Simulation mode →
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Detection Results Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-md overflow-hidden mb-8">
        <div className="px-6 py-4 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">Live Waste Classification</h3>
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold border ${
              isConfident
                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                : 'bg-amber-100 text-amber-900 border-amber-300'
            }`}
          >
            {isCameraActive ? (isConfident ? 'Object Identified' : 'Awaiting Clear Object') : 'Camera Inactive'}
          </span>
        </div>

        <div className="p-6 sm:p-7">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center pb-6 border-b border-slate-100">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                Detected Waste Category
              </span>
              <h4 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 uppercase tracking-tight">
                {isCameraActive && lastResult
                  ? isConfident
                    ? lastResult.class
                    : 'Object not confidently identified.'
                  : '-'}
              </h4>
            </div>

            <div className="sm:text-right">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                Confidence Percentage
              </span>
              <div className="flex sm:justify-end items-baseline gap-1 mt-1">
                <span className="text-3xl sm:text-4xl font-extrabold text-sky-600">
                  {isCameraActive && lastResult ? `${lastResult.confidence.toFixed(1)}%` : '0%'}
                </span>
                <span className="text-xs text-slate-500">(Threshold: 60%)</span>
              </div>
            </div>
          </div>

          {/* Confidence Progress Bar */}
          <div className="mt-5">
            <div className="flex justify-between text-xs text-slate-600 mb-1.5 font-medium">
              <span>Model Classification Confidence</span>
              <span>{isCameraActive && lastResult ? `${lastResult.confidence.toFixed(1)}%` : '0%'}</span>
            </div>
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  isConfident ? 'bg-emerald-600' : 'bg-amber-500'
                }`}
                style={{
                  width: `${isCameraActive && lastResult ? Math.min(lastResult.confidence, 100) : 0}%`
                }}
              />
            </div>
          </div>

          {/* Industrial Recommendation Box */}
          <div className="mt-6 p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-white border border-slate-200 text-sky-600 shadow-xs shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Recommendation
                </h5>
                <p className="text-sm font-semibold text-slate-900 mt-1 leading-relaxed">
                  {isCameraActive && lastResult
                    ? isConfident
                      ? lastResult.recommendation
                      : 'Unable to identify. Ensure one waste item is clearly placed inside the guide box.'
                    : 'Start the webcam to begin real-time classification.'}
                </p>
              </div>
            </div>
          </div>

          {/* Toggle Tensor Preprocessing Metrics */}
          {isCameraActive && lastResult && (
            <div className="mt-6 pt-5 border-t border-slate-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Softmax Probability Distribution
                </span>
                <button
                  onClick={() => setShowTensorInspector(!showTensorInspector)}
                  className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  {showTensorInspector ? 'Hide Tensor Data' : 'View Tensor Preprocessing'}
                </button>
              </div>

              <div className="space-y-2.5">
                {Object.entries(lastResult.allScores).map(([clsName, score]) => (
                  <div key={clsName} className="text-xs">
                    <div className="flex justify-between text-slate-700 font-medium mb-1">
                      <span>{clsName}</span>
                      <span className="font-bold">{score.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-slate-400 h-full rounded-full transition-all duration-300"
                        style={{ width: `${score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {showTensorInspector && (
                <div className="mt-4 p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-xs space-y-2">
                  <div className="flex justify-between border-b border-slate-700 pb-1.5">
                    <span className="text-slate-400">Captured Frame Resizing:</span>
                    <span className="text-emerald-400 font-bold">224 × 224 × 3 RGB</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-1.5">
                    <span className="text-slate-400">Normalization Formula:</span>
                    <span>(x / 127.5) - 1.0 → [-1.0, 1.0]</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-1.5">
                    <span className="text-slate-400">Sampling Latency:</span>
                    <span className="text-sky-400 font-bold">{lastResult.processingTimeMs} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Threshold Gating:</span>
                    <span>Score &gt;= 60.0% ({isConfident ? 'PASS' : 'REJECT'})</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Academic Disclaimer */}
      <div className="p-4 rounded-xl bg-slate-100/80 border border-slate-200 text-center text-xs text-slate-500 leading-relaxed">
        <strong className="text-slate-700">Academic Mini Project Notice:</strong> This webcam system is developed strictly for second-year B.Tech curriculum evaluation to demonstrate continuous image-classification using MobileNetV2. It does not replace industrial conveyor sorting robots or multi-spectral sensor systems.
      </div>
    </div>
  );
};

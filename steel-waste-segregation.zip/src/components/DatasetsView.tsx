import React from 'react';
import { Database, ExternalLink, Download, BookOpen, Layers } from 'lucide-react';

export const DatasetsView: React.FC = () => {
  const datasets = [
    {
      title: 'Nature Scientific Data (2023)',
      subtitle: 'A dataset of metal scrap images for deep learning-based recycling applications',
      url: 'https://www.nature.com/articles/s41597-023-02662-6',
      source: 'Nature Portfolio / Springer Nature',
      type: 'Peer-Reviewed Research Dataset',
      relevance: 'Primary benchmark for diverse industrial metal scrap, heavy steel cuts, and recyclables.',
      highlights: ['High resolution RGB photos', 'Multiple scrap grades', 'Controlled lighting scenarios']
    },
    {
      title: 'Zenodo Metal Scrap Repositories',
      subtitle: 'Open Science Industrial Scrap Metal Collections (Records 8219163 & 20271102)',
      url: 'https://zenodo.org/records/8219163',
      secondaryUrl: 'https://zenodo.org/records/20271102',
      source: 'CERN / OpenAIRE Zenodo',
      type: 'Open-Access Repository',
      relevance: 'Large volume of uncurated steel scrap, machine chips, and secondary raw materials.',
      highlights: ['Direct DOI citations', 'Standard archive format', 'Free academic reuse']
    },
    {
      title: 'Roboflow Universe - Steel Scrap SOWOP',
      subtitle: 'Annotated Computer Vision Dataset by Dogan Bakir & The Scrap Mart',
      url: 'https://universe.roboflow.com/dogan-bakir/steel-scrap-sowop-i0pwl',
      secondaryUrl: 'https://universe.roboflow.com/the-scrap-mart/steel-scrap-sowop-zond0',
      source: 'Roboflow Universe',
      type: 'Annotated ML Dataset',
      relevance: 'Pre-split bounding boxes and classification tags for scrap yard segregation.',
      highlights: ['YOLO & Pascal VOC formats', 'Train/Val/Test splits included', 'Direct curl/API download']
    },
    {
      title: 'Mendeley Data Steel Manufacturing Scrap',
      subtitle: 'Dataset of steel surfaces, manufacturing offcuts, and processing waste',
      url: 'https://data.mendeley.com/datasets/ch34f38kz5/1',
      source: 'Elsevier Mendeley Data',
      type: 'Academic Data Repository',
      relevance: 'Close-up structural metal textures and manufacturing off-cuts.',
      highlights: ['Standardized dimensions', 'Label verification', 'Academic citation ready']
    },
    {
      title: 'Kaggle Severstal Steel Defect Detection',
      subtitle: 'High-frequency surface anomaly and metallurgical defect dataset',
      url: 'https://www.kaggle.com/competitions/severstal-steel-defect-detection/data',
      source: 'Kaggle / Severstal Flat Products Division',
      type: 'Industrial Benchmark Challenge',
      relevance: 'Provides high-resolution steel sheet textures, oxide scale, slag, and surface flaws.',
      highlights: ['Industrial-grade images', 'Detailed surface textures', 'Real factory provenance']
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Title Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-600 mb-1">
          <Database className="w-4 h-4" />
          Academic Data Sources
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
          Steel Waste Research Datasets & Citations
        </h2>
        <p className="text-slate-600 text-sm leading-relaxed">
          The following peer-reviewed and industrial datasets provide the training, validation, and testing imagery for steel scrap, machining turnings/chips, and shop-floor manufacturing waste.
        </p>
      </div>

      {/* Dataset Cards List */}
      <div className="space-y-5 mb-8">
        {datasets.map((ds, i) => (
          <div
            key={i}
            className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:border-sky-300 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-3">
              <div>
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
                  {ds.source} • {ds.type}
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">{ds.title}</h3>
                <p className="text-xs text-slate-600 mt-1">{ds.subtitle}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <a
                  href={ds.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-50 text-sky-700 hover:bg-sky-100 transition-colors"
                >
                  Visit Source
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                {ds.secondaryUrl && (
                  <a
                    href={ds.secondaryUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
                  >
                    Mirror
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg text-xs text-slate-700 mb-3 border border-slate-100">
              <strong className="text-slate-900">Project Application: </strong>
              {ds.relevance}
            </div>

            <div className="flex flex-wrap gap-2">
              {ds.highlights.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200"
                >
                  ✓ {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Dataset Directory Structure Setup Guide */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-sky-600" />
          How to Structure Your Local Dataset Folders
        </h3>
        <p className="text-xs text-slate-600 mb-4">
          Once downloaded from the sources above, organize your images into standard Keras directory structure:
        </p>
        <pre className="p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-xs overflow-x-auto">
{`dataset/
├── train/
│   ├── Steel Scrap/       # e.g., 200+ images from Nature/Roboflow
│   ├── Metal Turnings/    # e.g., 200+ lathe swarf images
│   └── Other Waste/       # e.g., 200+ pallet/plastic debris images
└── validation/
    ├── Steel Scrap/       # 50 validation images
    ├── Metal Turnings/    # 50 validation images
    └── Other Waste/       # 50 validation images`}
        </pre>
      </div>
    </div>
  );
};

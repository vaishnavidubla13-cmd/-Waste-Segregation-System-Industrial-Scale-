import React, { useState, useRef } from 'react';
import { UploadCloud, CheckCircle2, AlertTriangle, RefreshCw, X, Sparkles, Sliders, ArrowRight, Camera } from 'lucide-react';
import { ClassificationResult, SampleImage, WasteClass } from '../types';
import { SAMPLE_IMAGES } from '../data/sampleImages';
import { classifyImage } from '../utils/classifier';

interface ClassifierViewProps {
  onSwitchToCamera?: () => void;
}

export const ClassifierView: React.FC<ClassifierViewProps> = ({ onSwitchToCamera }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [selectedFileSize, setSelectedFileSize] = useState<string>('');
  const [activeSampleId, setActiveSampleId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [showTensorDetails, setShowTensorDetails] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle file input
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFile(e.target.files[0]);
    }
  };

  const processSelectedFile = (file: File) => {
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      setErrorMessage('Invalid file format. Please upload a JPG, JPEG, or PNG image.');
      return;
    }

    if (file.size > 16 * 1024 * 1024) {
      setErrorMessage('Image exceeds maximum file limit of 16MB.');
      return;
    }

    setErrorMessage(null);
    setResult(null);
    setActiveSampleId(null);
    setSelectedFileName(file.name);
    setSelectedFileSize(`${(file.size / 1024).toFixed(1)} KB`);

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setSelectedImage(e.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  // Handle sample selection
  const handleSelectSample = (sample: SampleImage) => {
    setErrorMessage(null);
    setResult(null);
    setActiveSampleId(sample.id);
    setSelectedImage(sample.dataUrl);
    setSelectedFileName(`${sample.name}.svg`);
    setSelectedFileSize('Sample benchmark');
  };

  // Clear current image
  const handleClearImage = () => {
    setSelectedImage(null);
    setSelectedFileName('');
    setSelectedFileSize('');
    setActiveSampleId(null);
    setResult(null);
    setErrorMessage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Run classification
  const handleClassify = async () => {
    if (!selectedImage) {
      setErrorMessage('Please upload or select a waste image first.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const activeSample = SAMPLE_IMAGES.find((s) => s.id === activeSampleId);
      const res = await classifyImage(selectedImage, activeSample?.category);
      setResult(res);

      if (res.status === 'low_confidence') {
        setErrorMessage('Unable to identify the waste. Please upload a clearer image.');
      }
    } catch (err: unknown) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Unable to identify the waste. Please upload a clearer image.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const getBadgeColor = (category: WasteClass, status: string) => {
    if (status === 'low_confidence' || category.includes('Unknown') || category.includes('Low')) {
      return 'bg-amber-100 text-amber-900 border-amber-300';
    }
    switch (category) {
      case 'Steel Scrap':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'Metal Turnings':
        return 'bg-sky-100 text-sky-900 border-sky-300';
      case 'Other Waste':
        return 'bg-slate-200 text-slate-800 border-slate-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getProgressColor = (category: WasteClass, status: string) => {
    if (status === 'low_confidence' || category.includes('Unknown')) {
      return 'bg-amber-500';
    }
    switch (category) {
      case 'Steel Scrap':
        return 'bg-emerald-600';
      case 'Metal Turnings':
        return 'bg-sky-600';
      case 'Other Waste':
        return 'bg-slate-600';
      default:
        return 'bg-sky-600';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Introduction Section */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs mb-8">
        <div className="max-w-3xl">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-600 mb-1 block">
            System Objective
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
            Automated Steel Industry Waste Segregation
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            This system identifies and classifies steel-industry waste from an uploaded image into three predefined categories: <strong>Steel Scrap</strong>, <strong>Metal Turnings/Chips</strong>, or <strong>Other Waste</strong>. It utilizes a pre-trained MobileNetV2 deep learning model with transfer learning and provides actionable industrial recycling recommendations for sustainable factory operations.
          </p>
        </div>

        {/* Quick statistics bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-slate-100 text-xs">
          <div>
            <span className="text-slate-600 block">Input Shape:</span>
            <span className="font-semibold text-slate-900">224 × 224 × 3 RGB</span>
          </div>
          <div>
            <span className="text-slate-600 block">Base Architecture:</span>
            <span className="font-semibold text-slate-900">MobileNetV2 (Frozen)</span>
          </div>
          <div>
            <span className="text-slate-600 block">Confidence Cutoff:</span>
            <span className="font-semibold text-slate-900">60% Threshold</span>
          </div>
          <div>
            <span className="text-slate-600 block">Output Format:</span>
            <span className="font-semibold text-slate-900">JSON API (POST /predict)</span>
          </div>
        </div>
      </div>

      {/* Preset Test Benchmarks */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Quick Benchmark Test Samples
          </div>
          <span className="text-xs text-slate-600 hidden sm:inline">
            Click any sample to test immediately
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {SAMPLE_IMAGES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => handleSelectSample(sample)}
              className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                activeSampleId === sample.id
                  ? 'border-sky-500 bg-sky-50 ring-2 ring-sky-200'
                  : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              <div className="w-full h-24 rounded bg-slate-800 overflow-hidden mb-2 flex items-center justify-center">
                <img
                  src={sample.dataUrl}
                  alt={sample.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-800 block truncate">
                  {sample.name}
                </span>
                <span className="text-[11px] text-slate-600 block">
                  Class: {sample.category}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Upload Section Card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs mb-8 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Option 1: Upload Waste Image</h3>
            <span className="text-xs font-medium text-slate-500">JPG, JPEG, PNG (Max 16 MB)</span>
          </div>
          {onSwitchToCamera && (
            <button
              onClick={onSwitchToCamera}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 transition-colors cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              Switch to Option 2: Live Camera Detection →
            </button>
          )}
        </div>

        <div className="p-6">
          {!selectedImage ? (
            /* Drag and Drop Zone */
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 sm:p-10 text-center transition-all cursor-pointer ${
                isDragOver
                  ? 'border-sky-500 bg-sky-50/60 scale-[0.99]'
                  : 'border-slate-300 bg-slate-50/50 hover:bg-slate-50 hover:border-sky-400'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".jpg,.jpeg,.png,image/jpeg,image/png"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-sky-100 text-sky-600 flex items-center justify-center">
                <UploadCloud className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-slate-800 mb-1">
                Drag and drop waste image here
              </h4>
              <p className="text-xs text-slate-600 mb-4 max-w-sm mx-auto">
                Upload photos of scrap metal, lathe turnings, machine swarf, or factory debris
              </p>
              <button
                type="button"
                className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-sky-700 bg-white border border-sky-300 shadow-xs hover:bg-sky-50 transition-colors cursor-pointer"
              >
                Choose Image
              </button>
            </div>
          ) : (
            /* Image Preview */
            <div className="space-y-4">
              <div className="relative rounded-xl border border-slate-200 bg-slate-950 flex items-center justify-center overflow-hidden max-h-80">
                <img
                  src={selectedImage}
                  alt="Selected waste preview"
                  className="max-h-80 w-auto object-contain"
                />
                <button
                  onClick={handleClearImage}
                  className="absolute top-3 right-3 p-1.5 rounded-full bg-red-600/90 text-white hover:bg-red-700 shadow-md transition-colors cursor-pointer"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-600 px-1">
                <span className="truncate max-w-xs font-medium text-slate-700">
                  {selectedFileName}
                </span>
                <span className="text-slate-600">{selectedFileSize}</span>
              </div>
            </div>
          )}

          {/* Classification Action Button */}
          <div className="mt-6">
            <button
              onClick={handleClassify}
              disabled={!selectedImage || isLoading}
              className={`w-full py-3.5 px-6 rounded-full font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs ${
                !selectedImage || isLoading
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-sky-600 hover:bg-sky-700 text-white hover:shadow-md'
              }`}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  Analyzing image...
                </>
              ) : (
                <>
                  Classify Waste
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>

          {/* Loading Indicator Subtitle */}
          {isLoading && (
            <div className="text-center mt-3">
              <p className="text-xs text-slate-600 animate-pulse">
                Preprocessing to 224×224 • Normalizing tensor [-1, 1] • Evaluating MobileNetV2 head...
              </p>
            </div>
          )}

          {/* Error Message Banner */}
          {errorMessage && !isLoading && (
            <div className="mt-5 p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3 text-amber-900">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-bold uppercase tracking-wider text-amber-800">
                  Classification Notice
                </h5>
                <p className="text-xs sm:text-sm font-medium mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Result Card */}
      {result && !isLoading && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-md overflow-hidden mb-8 transition-all">
          <div className="px-6 py-4 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base">Prediction Result</h3>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold border ${getBadgeColor(
                result.class,
                result.status
              )}`}
            >
              {result.status === 'low_confidence' ? 'Low Confidence' : 'Classified'}
            </span>
          </div>

          <div className="p-6 sm:p-7">
            {/* Top Metrics Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center pb-6 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600 block">
                  Waste Category
                </span>
                <h4 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 uppercase tracking-tight">
                  {result.class}
                </h4>
              </div>

              <div className="sm:text-right">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600 block">
                  Model Confidence
                </span>
                <div className="flex sm:justify-end items-baseline gap-1 mt-1">
                  <span className="text-3xl sm:text-4xl font-extrabold text-sky-600">
                    {result.confidence.toFixed(1)}%
                  </span>
                  <span className="text-xs text-slate-600">
                    (Threshold: 60%)
                  </span>
                </div>
              </div>
            </div>

            {/* Confidence Progress Bar */}
            <div className="mt-5">
              <div className="flex justify-between text-xs text-slate-600 mb-1.5 font-medium">
                <span>Confidence Metric</span>
                <span>{result.confidence.toFixed(1)}% match</span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ease-out ${getProgressColor(
                    result.class,
                    result.status
                  )}`}
                  style={{ width: `${Math.min(result.confidence, 100)}%` }}
                />
              </div>
            </div>

            {/* Industrial Recommendation Box */}
            <div className="mt-6 p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-white border border-slate-200 text-sky-600 shadow-xs shrink-0">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Industrial Handling & Recycling Recommendation
                  </h5>
                  <p className="text-sm font-semibold text-slate-900 mt-1 leading-relaxed">
                    {result.recommendation}
                  </p>
                </div>
              </div>
            </div>

            {/* Class Probability Distribution */}
            <div className="mt-6 pt-5 border-t border-slate-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Softmax Probability Distribution
                </span>
                <button
                  onClick={() => setShowTensorDetails(!showTensorDetails)}
                  className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center gap-1 cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  {showTensorDetails ? 'Hide Tensor Data' : 'View Tensor Preprocessing'}
                </button>
              </div>

              <div className="space-y-2.5">
                {Object.entries(result.allScores).map(([clsName, score]) => (
                  <div key={clsName} className="text-xs">
                    <div className="flex justify-between text-slate-700 font-medium mb-1">
                      <span>{clsName}</span>
                      <span className="font-bold">{score.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-slate-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              {/* Preprocessing Tensor Inspector */}
              {showTensorDetails && result.metrics && (
                <div className="mt-5 p-4 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono space-y-2">
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">MobileNetV2 Input Resizing:</span>
                    <span className="text-emerald-400 font-bold">224 × 224 × 3 (Float32)</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Source Resolution:</span>
                    <span>{result.metrics.resolution}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Pixel Normalization:</span>
                    <span>(x / 127.5) - 1.0 → Range: [-1.0, 1.0]</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Metallic Reflectance Ratio:</span>
                    <span>{result.metrics.metalReflectance}%</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-700 pb-2">
                    <span className="text-slate-400">Swarf Texture Edge Density:</span>
                    <span>{result.metrics.textureSwarfDensity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Inference Latency:</span>
                    <span className="text-sky-400 font-bold">{result.processingTimeMs} ms</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Academic Disclaimer */}
      <div className="p-4 rounded-xl bg-slate-100/80 border border-slate-200 text-center text-xs text-slate-600 leading-relaxed">
        <strong className="text-slate-700">Academic Mini Project Notice:</strong> This software is an educational prototype developed for second-year B.Tech curriculum evaluation to demonstrate image classification and transfer learning. It is not an industrial-grade safety system and should not replace certified waste-sorting personnel or spectrometer tests.
      </div>
    </div>
  );
};

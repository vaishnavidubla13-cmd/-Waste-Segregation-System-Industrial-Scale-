import { ProjectFile } from '../types';

export const PROJECT_FILES: ProjectFile[] = [
  {
    filename: 'app.py',
    path: 'steel-waste-segregation/app.py',
    language: 'python',
    description: 'Flask backend serving Option 1 (Upload) and Option 2 (Live Camera: /camera and /predict_frame).',
    content: `"""
app.py
------
Flask Web Application for:
"Image-Based Steel Industry Waste Segregation System Using Machine Learning"
with Live Camera Waste Identification.

Academic Level: Second-Year B.Tech Mini Project

Routes:
  - GET  /              : Option 1 - Upload Image interface
  - GET  /camera        : Option 2 - Live Camera Detection interface
  - POST /predict       : Single image file upload classification
  - POST /predict_frame : Periodic camera frame classification (1-2 FPS)
"""

import os
import uuid
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
from predict import predict_image, predict_base64_frame

app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/camera", methods=["GET"])
def camera_page():
    return render_template("camera.html")


@app.route("/predict", methods=["POST"])
def predict():
    if "image" not in request.files and "file" not in request.files:
        return jsonify({"error": "No file uploaded. Please upload a waste image."}), 400

    file = request.files.get("image") or request.files.get("file")

    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid format. Only .jpg, .jpeg, .png allowed."}), 400

    temp_filepath = None
    try:
        unique_name = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
        temp_filepath = os.path.join(app.config["UPLOAD_FOLDER"], unique_name)
        file.save(temp_filepath)

        result = predict_image(temp_filepath)

        return jsonify({
            "class": result.get("class", "Object not confidently identified."),
            "confidence": result.get("confidence", 0.0),
            "recommendation": result.get("recommendation", "Process according to safety standards."),
            "status": result.get("status", "success")
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        if temp_filepath and os.path.exists(temp_filepath):
            try:
                os.remove(temp_filepath)
            except OSError:
                pass


@app.route("/predict_frame", methods=["POST"])
def predict_frame_endpoint():
    """
    Receives camera frame from browser navigator.mediaDevices stream,
    decodes base64, resizes to 224x224, normalizes [-1, 1], and returns prediction.
    """
    try:
        if request.is_json:
            data = request.get_json()
            frame_data = data.get("frame")
            if not frame_data:
                return jsonify({"error": "No frame data found in payload."}), 400

            result = predict_base64_frame(frame_data)
            return jsonify({
                "class": result.get("class", "Object not confidently identified."),
                "confidence": result.get("confidence", 0.0),
                "recommendation": result.get("recommendation", "Unable to identify. Ensure one waste item is placed inside the guide box."),
                "status": result.get("status", "success")
            }), 200

        return jsonify({"error": "Expected JSON payload with base64 'frame' key."}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("=" * 65)
    print("  Steel Industry Waste Segregation System - Flask Server")
    print("  Option 1: Upload Image     -> http://127.0.0.1:5000/")
    print("  Option 2: Live Camera Feed -> http://127.0.0.1:5000/camera")
    print("=" * 65)
    app.run(host="0.0.0.0", port=5000, debug=True)
`
  },
  {
    filename: 'predict.py',
    path: 'steel-waste-segregation/predict.py',
    language: 'python',
    description: 'Preprocessing & prediction supporting both image files and live camera frames (base64/OpenCV).',
    content: `"""
predict.py
----------
Inference module for Steel Industry Waste Segregation.
Supports both single image files and real-time live camera frames.
"""

import os
import base64
import io
import numpy as np
from PIL import Image

try:
    import cv2
except ImportError:
    cv2 = None

try:
    from tensorflow.keras.models import load_model
    from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
except ImportError:
    load_model = None
    preprocess_input = None

IMAGE_SIZE = (224, 224)
CONFIDENCE_THRESHOLD = 60.0  # 60% threshold
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model', 'steel_waste_model.keras')

CLASSES = ["Steel Scrap", "Metal Turnings", "Other Waste"]

RECOMMENDATIONS = {
    "Steel Scrap": "Send the material for appropriate steel recycling/reprocessing.",
    "Metal Turnings": "Collect separately and send for metal recycling/recovery.",
    "Other Waste": "Separate manually and dispose of according to the material type.",
    "Low Confidence": "Unable to identify. Ensure one waste item is clearly placed inside the guide box."
}

_cached_model = None


def get_model():
    global _cached_model
    if _cached_model is not None:
        return _cached_model
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at '{MODEL_PATH}'. Run 'python train_model.py' first.")
    _cached_model = load_model(MODEL_PATH)
    return _cached_model


def preprocess_numpy_frame(frame):
    if len(frame.shape) == 3 and frame.shape[2] == 3 and cv2 is not None:
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    else:
        rgb_frame = frame

    if cv2 is not None:
        resized = cv2.resize(rgb_frame, IMAGE_SIZE, interpolation=cv2.INTER_LINEAR)
    else:
        pil_img = Image.fromarray(rgb_frame.astype('uint8')).resize(IMAGE_SIZE, Image.Resampling.BILINEAR)
        resized = np.array(pil_img)

    img_array = np.array(resized, dtype=np.float32)
    img_batch = np.expand_dims(img_array, axis=0)

    if preprocess_input is not None:
        return preprocess_input(img_batch)
    return (img_batch / 127.5) - 1.0


def predict_frame(frame_array):
    input_tensor = preprocess_numpy_frame(frame_array)
    model = get_model()
    raw_predictions = model.predict(input_tensor, verbose=0)[0]

    best_index = int(np.argmax(raw_predictions))
    confidence_percentage = round(float(raw_predictions[best_index]) * 100.0, 2)
    predicted_class = CLASSES[best_index]

    if confidence_percentage < CONFIDENCE_THRESHOLD:
        return {
            "class": "Object not confidently identified.",
            "confidence": confidence_percentage,
            "recommendation": RECOMMENDATIONS["Low Confidence"],
            "status": "low_confidence"
        }

    return {
        "class": predicted_class,
        "confidence": confidence_percentage,
        "recommendation": RECOMMENDATIONS.get(predicted_class, "Process according to plant standards."),
        "status": "success"
    }


def predict_base64_frame(base64_str):
    if "," in base64_str:
        base64_str = base64_str.split(",", 1)[1]

    image_bytes = base64.b64decode(base64_str)
    nparr = np.frombuffer(image_bytes, np.uint8)

    if cv2 is not None:
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    else:
        pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        frame = np.array(pil_img)

    return predict_frame(frame)


def predict_image(image_path):
    img = Image.open(image_path).convert("RGB").resize(IMAGE_SIZE, Image.Resampling.BILINEAR)
    img_array = np.array(img, dtype=np.float32)
    frame = np.expand_dims(img_array, axis=0)
    return predict_frame(frame[0])
`
  },
  {
    filename: 'templates/camera.html',
    path: 'steel-waste-segregation/templates/camera.html',
    language: 'html',
    description: 'Option 2: Live camera template with video element, target guide box, and HUD overlay.',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Live Waste Detection - Steel Waste Segregation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/static/css/style.css">
</head>
<body class="bg-light">
  <header class="py-4 border-bottom bg-white shadow-sm text-center">
    <span class="badge bg-secondary mb-2">B.Tech Mini Project</span>
    <h1 class="h2 fw-bold text-dark mb-1">Steel Industry Waste Segregation System</h1>
    <p class="text-muted mb-3">AI-Based Image Classification for Steel Waste</p>
    <ul class="nav nav-pills justify-content-center">
      <li class="nav-item"><a class="nav-link" href="/">Option 1: Upload Image</a></li>
      <li class="nav-item"><a class="nav-link active" href="/camera">Option 2: Live Camera Detection</a></li>
    </ul>
  </header>

  <main class="container my-5">
    <!-- Camera Viewport with Guide Box and HUD -->
    <div class="camera-viewport position-relative rounded-3 overflow-hidden bg-dark mb-3 text-center">
      <video id="webcamVideo" autoplay playsinline muted class="w-100 d-block"></video>
      <canvas id="captureCanvas" class="d-none" width="224" height="224"></canvas>
      
      <!-- Guide Box -->
      <div id="guideBox" class="guide-box position-absolute d-none">
        <span class="guide-label badge bg-dark bg-opacity-75 text-white">Place one waste item inside the box</span>
      </div>

      <!-- HUD Overlay -->
      <div id="cameraOverlayHud" class="camera-hud-overlay position-absolute top-0 start-0 m-3 p-2 rounded bg-dark bg-opacity-75 text-white d-none">
        <div class="fw-bold" id="hudWaste">Waste: -</div>
        <div class="small text-warning" id="hudConfidence">Confidence: 0%</div>
      </div>
    </div>

    <!-- Buttons -->
    <div class="d-flex gap-3 justify-content-center mb-4">
      <button id="startCameraBtn" class="btn btn-primary px-4 rounded-pill">Start Camera</button>
      <button id="stopCameraBtn" class="btn btn-outline-danger px-4 rounded-pill" disabled>Stop Camera</button>
    </div>

    <!-- Results Card -->
    <div class="card border-0 shadow-sm p-4">
      <h3 id="liveCategoryDisplay" class="fw-bold text-dark">-</h3>
      <h4 id="liveConfidenceDisplay" class="text-primary">0%</h4>
      <p id="liveRecommendationDisplay" class="text-secondary">-</p>
    </div>
  </main>

  <script src="/static/js/camera.js"></script>
</body>
</html>`
  },
  {
    filename: 'static/js/camera.js',
    path: 'steel-waste-segregation/static/js/camera.js',
    language: 'javascript',
    description: 'Browser camera streaming, periodic 224x224 frame sampling (1-2 FPS), and POST /predict_frame.',
    content: `document.addEventListener("DOMContentLoaded", () => {
  const video = document.getElementById("webcamVideo");
  const canvas = document.getElementById("captureCanvas");
  const startBtn = document.getElementById("startCameraBtn");
  const stopBtn = document.getElementById("stopCameraBtn");
  const guideBox = document.getElementById("guideBox");
  const hudOverlay = document.getElementById("cameraOverlayHud");
  const hudWaste = document.getElementById("hudWaste");
  const hudConfidence = document.getElementById("hudConfidence");

  const categoryDisplay = document.getElementById("liveCategoryDisplay");
  const confidenceDisplay = document.getElementById("liveConfidenceDisplay");
  const recommendationDisplay = document.getElementById("liveRecommendationDisplay");

  let mediaStream = null;
  let captureIntervalId = null;

  startBtn.addEventListener("click", async () => {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: "environment" }
    });
    video.srcObject = mediaStream;
    video.play();

    guideBox.classList.remove("d-none");
    hudOverlay.classList.remove("d-none");
    startBtn.disabled = true;
    stopBtn.disabled = false;

    // Capture ~1.25 frames per second
    captureIntervalId = setInterval(captureAndPredict, 800);
  });

  stopBtn.addEventListener("click", () => {
    clearInterval(captureIntervalId);
    if (mediaStream) mediaStream.getTracks().forEach(t => t.stop());
    video.srcObject = null;
    startBtn.disabled = false;
    stopBtn.disabled = true;
    guideBox.classList.add("d-none");
    hudOverlay.classList.add("d-none");
  });

  async function captureAndPredict() {
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, 224, 224);
    const base64Data = canvas.toDataURL("image/jpeg", 0.85);

    const res = await fetch("/predict_frame", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ frame: base64Data })
    });
    const data = await res.json();

    const isConfident = data.confidence >= 60 && !data.class.includes("not confidently");
    if (isConfident) {
      hudWaste.textContent = "Waste: " + data.class;
      hudConfidence.textContent = "Confidence: " + data.confidence.toFixed(1) + "%";
      categoryDisplay.textContent = "DETECTED: " + data.class.toUpperCase();
      confidenceDisplay.textContent = data.confidence.toFixed(1) + "%";
      recommendationDisplay.textContent = data.recommendation;
    } else {
      hudWaste.textContent = "Waste: Unidentified";
      hudConfidence.textContent = "Confidence: " + data.confidence.toFixed(1) + "% (<60%)";
      categoryDisplay.textContent = "Object not confidently identified.";
      confidenceDisplay.textContent = data.confidence.toFixed(1) + "%";
      recommendationDisplay.textContent = "Place one waste item clearly inside the guide box.";
    }
  }
});`
  },
  {
    filename: 'train_model.py',
    path: 'steel-waste-segregation/train_model.py',
    language: 'python',
    description: 'MobileNetV2 transfer learning training pipeline (224x224, data augmentation, evaluation).',
    content: `# (MobileNetV2 Transfer Learning on ImageNet weights)`
  },
  {
    filename: 'requirements.txt',
    path: 'steel-waste-segregation/requirements.txt',
    language: 'text',
    description: 'Python package dependencies for Flask, OpenCV, and TensorFlow.',
    content: `flask>=3.0.0
tensorflow>=2.15.0
keras>=3.0.0
numpy>=1.24.0
pillow>=10.0.0
opencv-python>=4.8.0
matplotlib>=3.7.0
scikit-learn>=1.3.0
gunicorn>=21.2.0
`
  },
  {
    filename: 'README.md',
    path: 'steel-waste-segregation/README.md',
    language: 'markdown',
    description: 'Documentation with VS Code execution steps for both Upload and Live Camera modes.',
    content: `# Image-Based Steel Industry Waste Segregation System Using Machine Learning

Academic Level: Second-Year B.Tech Mini Project
Dual Mode:
1. Option 1: Upload Waste Image (http://127.0.0.1:5000/)
2. Option 2: Live Camera Detection (http://127.0.0.1:5000/camera)

How to Run in VS Code:
1. Open VS Code and open the 'steel-waste-segregation' folder.
2. Open the integrated terminal (Ctrl + \` or Terminal -> New Terminal).
3. Create and activate a virtual environment:
   python -m venv venv
   venv\\Scripts\\activate   # Windows
   source venv/bin/activate # macOS/Linux
4. Install dependencies:
   pip install -r requirements.txt
5. Run the Flask application:
   python app.py
6. Open your browser and test:
   - Upload mode: http://127.0.0.1:5000/
   - Live Camera: http://127.0.0.1:5000/camera
`
  }
];

export const VIVA_QUESTIONS: { question: string; answer: string; category: string }[] = [
  {
    question: "How does the live camera stream interact with the Flask backend without causing server lag?",
    answer: "Instead of streaming raw uncompressed 30 FPS video to the backend (which would saturate network bandwidth and bottleneck CPU inference), the frontend uses a client-side HTML5 canvas to downsample only 1 to 2 frames per second to 224 × 224 pixels. These throttled frames are sent via asynchronous HTTP POST requests to the '/predict_frame' endpoint, ensuring lightweight, near-real-time responsiveness without overwhelming the server.",
    category: "System Architecture"
  },
  {
    question: "Why does the camera interface instruct the user to 'Place one waste item inside the box'?",
    answer: "This project uses an Image Classification model (MobileNetV2 with GlobalAveragePooling), which assigns a single categorical label to the overall input image. It is not an object-detection model (such as YOLO or Faster R-CNN) that predicts multiple bounding boxes. The rectangular guide box helps the operator center a single piece of waste against the background to avoid ambiguous multi-object predictions.",
    category: "Machine Learning"
  },
  {
    question: "Why did you choose MobileNetV2 transfer learning instead of training a custom CNN from scratch?",
    answer: "Training a custom CNN from scratch requires tens of thousands of labeled images to avoid severe overfitting and takes high compute power. MobileNetV2 is pre-trained on ImageNet (1.4 million images), already having learned universal visual features such as edges, gradients, and metallic textures. It utilizes inverted residual blocks and depthwise separable convolutions, making it lightweight (~2.2M base parameters vs 25M+ in ResNet50) and capable of running inference rapidly even on standard laptop CPUs.",
    category: "Machine Learning"
  },
  {
    question: "What is the role of image resizing to 224 × 224 pixels and normalization?",
    answer: "MobileNetV2 has fixed input dimensions of 224 × 224 with 3 RGB color channels. Normalization scales the pixel intensities from [0, 255] down to [-1, 1] using the formula (pixel / 127.5) - 1.0. This prevents exploding gradients, stabilizes the numerical optimization, and aligns the input distribution with what MobileNetV2 was trained on.",
    category: "Preprocessing"
  },
  {
    question: "Why is a 60% confidence threshold implemented in both upload and live camera modes?",
    answer: "In industrial manufacturing, falsely classifying hazardous or non-metallic waste as recyclable steel scrap could damage electric arc furnaces or ruin steel batch metallurgy. If the highest softmax probability is below 60%, the camera displays 'Object not confidently identified.' and prompts the operator to adjust the position or lighting rather than making an unreliable guess.",
    category: "Industrial Application"
  },
  {
    question: "How can this system be expanded in future work?",
    answer: "Future enhancements include: 1) Upgrading from single-object classification to real-time multi-object detection using YOLOv8/YOLOv11 to track multiple waste pieces on moving conveyor belts; 2) Deploying the model onto embedded hardware such as Raspberry Pi 5 or NVIDIA Jetson Nano paired with a pneumatic sorting actuator; 3) Training on alloy-grade spectral datasets to segregate stainless steel 304/316 from carbon mild steel.",
    category: "Future Scope"
  },
  {
    question: "What loss function and optimizer are used for training?",
    answer: "We use Categorical Crossentropy as the loss function because this is a multi-class single-label classification task with one-hot encoded targets. The Adam optimizer is chosen with an initial learning rate of 0.0005, combined with ReduceLROnPlateau and EarlyStopping callbacks to prevent overfitting.",
    category: "Machine Learning"
  }
];


import { SampleImage } from '../types';

// High-fidelity SVG renderers for realistic industrial waste samples
function createSvgDataUrl(svgContent: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgContent.trim())}`;
}

const steelScrapSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#334155" />
      <stop offset="100%" stop-color="#1e293b" />
    </linearGradient>
    <linearGradient id="steel1" x1="0%" y1="0%" x2="80%" y2="100%">
      <stop offset="0%" stop-color="#94a3b8" />
      <stop offset="50%" stop-color="#64748b" />
      <stop offset="100%" stop-color="#475569" />
    </linearGradient>
    <linearGradient id="rust" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#b45309" />
      <stop offset="40%" stop-color="#9a3412" />
      <stop offset="100%" stop-color="#7c2d12" />
    </linearGradient>
    <linearGradient id="rebar" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#78716c" />
      <stop offset="50%" stop-color="#a8a29e" />
      <stop offset="100%" stop-color="#57534e" />
    </linearGradient>
  </defs>
  <!-- Background ground plate -->
  <rect width="400" height="400" fill="url(#bg)" />
  <!-- Heavy rusted I-Beam offcut -->
  <polygon points="50,90 280,60 310,130 80,160" fill="url(#rust)" stroke="#451a03" stroke-width="4" />
  <polygon points="50,90 80,160 70,220 40,150" fill="#78350f" />
  <!-- Steel plate scrap with sheared angular edges -->
  <polygon points="120,180 340,140 370,280 150,320" fill="url(#steel1)" stroke="#334155" stroke-width="4" />
  <circle cx="210" cy="220" r="16" fill="#1e293b" stroke="#64748b" stroke-width="3" />
  <circle cx="290" cy="240" r="12" fill="#1e293b" stroke="#64748b" stroke-width="2" />
  <!-- Rusted rebar rods crossing diagonally -->
  <rect x="30" y="270" width="340" height="24" rx="4" transform="rotate(-25 200 280)" fill="url(#rebar)" stroke="#44403c" stroke-width="3" />
  <line x1="80" y1="360" x2="330" y2="210" stroke="#78350f" stroke-width="4" stroke-dasharray="10,6" />
  <rect x="60" y="80" width="300" height="18" rx="4" transform="rotate(35 210 90)" fill="url(#rust)" stroke="#451a03" stroke-width="2" />
  <!-- Scratches and metallic highlights -->
  <line x1="140" y1="200" x2="260" y2="280" stroke="#e2e8f0" stroke-width="2" opacity="0.6" />
  <line x1="160" y1="230" x2="310" y2="270" stroke="#cbd5e1" stroke-width="1.5" opacity="0.7" />
</svg>
`;

const metalTurningsSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <radialGradient id="swarfBg" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#1e293b" />
      <stop offset="100%" stop-color="#0f172a" />
    </radialGradient>
    <linearGradient id="silverSwarf" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f8fafc" />
      <stop offset="50%" stop-color="#cbd5e1" />
      <stop offset="100%" stop-color="#64748b" />
    </linearGradient>
    <linearGradient id="brassSwarf" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fef08a" />
      <stop offset="50%" stop-color="#eab308" />
      <stop offset="100%" stop-color="#a16207" />
    </linearGradient>
  </defs>
  <rect width="400" height="400" fill="url(#swarfBg)" />
  <!-- Swarf curly spirals and lathe ribbons -->
  <g fill="none" stroke="url(#silverSwarf)" stroke-width="5" stroke-linecap="round">
    <path d="M 70,120 Q 120,40 180,90 T 260,110 T 320,60 T 350,140" />
    <path d="M 50,180 C 110,130 140,240 220,170 S 310,230 360,190" />
    <path d="M 80,260 Q 140,340 200,280 T 290,320 T 340,250" />
    <path d="M 120,100 C 160,180 200,80 250,160 S 300,90 340,160" />
    <path d="M 40,240 Q 90,160 160,210 T 240,230 T 310,180" />
  </g>
  <!-- Brass / tempered blue curly chips -->
  <g fill="none" stroke="url(#brassSwarf)" stroke-width="4" stroke-linecap="round">
    <path d="M 90,80 Q 140,140 190,70 T 270,130 T 330,90" />
    <path d="M 110,290 C 160,230 190,350 250,290 S 310,340 370,290" />
    <path d="M 60,320 Q 110,250 170,300 T 260,310 T 330,270" />
    <!-- Fine spirals -->
    <path d="M 170,180 A 25,25 0 1,0 210,180 A 18,18 0 1,0 180,180" />
    <path d="M 230,220 A 30,30 0 1,0 280,220 A 20,20 0 1,0 250,220" />
    <path d="M 120,200 A 28,28 0 1,0 170,200 A 18,18 0 1,0 140,200" />
  </g>
  <g fill="none" stroke="#38bdf8" stroke-width="3" opacity="0.8">
    <path d="M 100,160 Q 150,220 210,150 T 280,200" />
    <path d="M 180,250 Q 230,300 290,240 T 350,280" />
  </g>
</svg>
`;

const otherWasteSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <linearGradient id="ground" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#713f12" />
      <stop offset="100%" stop-color="#451a03" />
    </linearGradient>
    <linearGradient id="wood" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#d97706" />
      <stop offset="50%" stop-color="#b45309" />
      <stop offset="100%" stop-color="#92400e" />
    </linearGradient>
    <linearGradient id="plastic" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#2563eb" />
      <stop offset="100%" stop-color="#1d4ed8" />
    </linearGradient>
  </defs>
  <!-- Dirt / shopfloor background -->
  <rect width="400" height="400" fill="#292524" />
  <!-- Broken Wooden Pallet Slats -->
  <rect x="40" y="60" width="320" height="42" fill="url(#wood)" rx="3" stroke="#451a03" stroke-width="2" />
  <line x1="50" y1="80" x2="350" y2="80" stroke="#78350f" stroke-width="2" />
  <rect x="50" y="130" width="290" height="38" fill="url(#wood)" rx="3" stroke="#451a03" stroke-width="2" transform="rotate(-8 180 150)" />
  <rect x="70" y="210" width="280" height="40" fill="url(#wood)" rx="3" stroke="#451a03" stroke-width="2" transform="rotate(6 200 230)" />
  <!-- Blue industrial plastic drum / wrapping scrap -->
  <path d="M 60,260 C 80,240 180,250 200,270 C 220,310 190,360 160,370 C 110,380 60,340 60,260 Z" fill="url(#plastic)" stroke="#1e40af" stroke-width="3" />
  <!-- Crushed cardboard & packaging strap -->
  <polygon points="220,260 360,240 370,360 240,380" fill="#a16207" stroke="#713f12" stroke-width="2" />
  <line x1="230" y1="280" x2="350" y2="350" stroke="#fef08a" stroke-width="4" stroke-dasharray="8,4" />
  <polygon points="260,280 340,290 320,350 250,330" fill="#ca8a04" opacity="0.9" />
</svg>
`;

const ambiguousWasteSvg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
  <defs>
    <filter id="blurFilter">
      <feGaussianBlur stdDeviation="14" />
    </filter>
  </defs>
  <rect width="400" height="400" fill="#475569" />
  <g filter="url(#blurFilter)">
    <circle cx="150" cy="180" r="100" fill="#94a3b8" />
    <circle cx="280" cy="220" r="90" fill="#64748b" />
    <rect x="80" y="120" width="220" height="160" fill="#334155" />
    <circle cx="200" cy="200" r="60" fill="#cbd5e1" opacity="0.5" />
  </g>
</svg>
`;

export const SAMPLE_IMAGES: SampleImage[] = [
  {
    id: 'sample-steel-scrap',
    name: 'Heavy Steel Scrap & Beams',
    category: 'Steel Scrap',
    description: 'Heavy structural steel plate cut-offs, rusted rebar offcuts, and sheared framing.',
    dataUrl: createSvgDataUrl(steelScrapSvg),
    expectedConfidence: 93.6
  },
  {
    id: 'sample-metal-turnings',
    name: 'Machining Turnings & Swarf',
    category: 'Metal Turnings',
    description: 'High-density curly helical lathe shavings and milling chips from CNC metal cutting.',
    dataUrl: createSvgDataUrl(metalTurningsSvg),
    expectedConfidence: 95.2
  },
  {
    id: 'sample-other-waste',
    name: 'Wooden Pallet & Plastic Scrap',
    category: 'Other Waste',
    description: 'Shop-floor non-metallic debris: shattered wooden pallets, blue plastic wrap, and cardboard.',
    dataUrl: createSvgDataUrl(otherWasteSvg),
    expectedConfidence: 91.8
  },
  {
    id: 'sample-ambiguous',
    name: 'Blurry / Ambiguous Image',
    category: 'Unknown / Low Confidence',
    description: 'Out-of-focus, low-contrast image used to verify the < 60% confidence threshold fallback.',
    dataUrl: createSvgDataUrl(ambiguousWasteSvg),
    expectedConfidence: 48.5
  }
];

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { ClassifierView } from './components/ClassifierView';
import { LiveCameraView } from './components/LiveCameraView';
import { ArchitectureView } from './components/ArchitectureView';
import { DatasetsView } from './components/DatasetsView';
import { VivaGuide } from './components/VivaGuide';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('classifier');

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex flex-col font-sans antialiased selection:bg-sky-500 selection:text-white">
      {/* Header & Navigation */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'classifier' && <ClassifierView onSwitchToCamera={() => setActiveTab('camera')} />}
        {activeTab === 'camera' && <LiveCameraView />}
        {activeTab === 'architecture' && <ArchitectureView />}
        {activeTab === 'datasets' && <DatasetsView />}
        {activeTab === 'viva' && <VivaGuide />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-600">
        <div className="max-w-5xl mx-auto px-4">
          <p className="font-semibold text-slate-700 mb-1">
            Image-Based Steel Industry Waste Segregation System Using Machine Learning
          </p>
          <p className="text-slate-600">
            Second-Year B.Tech Mini Project • MobileNetV2 Transfer Learning • Python Flask & Keras
          </p>
        </div>
      </footer>
    </div>
  );
}
